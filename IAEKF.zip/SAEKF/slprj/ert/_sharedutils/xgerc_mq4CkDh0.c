/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: xgerc_mq4CkDh0.c
 *
 * Code generated for Simulink model 'IAEKF'.
 *
 * Model version                  : 5.36
 * Simulink Coder version         : 9.6 (R2021b) 14-May-2021
 * C/C++ source code generated on : Thu Jun  1 21:51:50 2023
 */

#include "rtwtypes.h"
#include "xgerc_mq4CkDh0.h"

/* Function for MATLAB Function: '<S24>/Predict' */
void xgerc_mq4CkDh0(int32_T m, int32_T n, real_T alpha1, int32_T ix0, const
                    real_T y[3], real_T A[18], int32_T ia0)
{
  int32_T j;
  if (!(alpha1 == 0.0)) {
    int32_T jA;
    int32_T jy;
    jA = ia0 - 1;
    jy = 0;
    for (j = 0; j < n; j++) {
      if (y[jy] != 0.0) {
        real_T temp;
        int32_T b;
        int32_T ijA;
        int32_T ix;
        temp = y[jy] * alpha1;
        ix = ix0;
        ijA = jA;
        b = m + jA;
        while ((ijA + 1) <= b) {
          A[ijA] += A[ix - 1] * temp;
          ix++;
          ijA++;
        }
      }

      jy++;
      jA += 6;
    }
  }
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
