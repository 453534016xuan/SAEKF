/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: rt_powd_snf.h
 *
 * Code generated for Simulink model 'IAEKF'.
 *
 * Model version                  : 5.36
 * Simulink Coder version         : 9.6 (R2021b) 14-May-2021
 * C/C++ source code generated on : Thu Jun  1 21:51:50 2023
 */

#ifndef RTW_HEADER_rt_powd_snf_h_
#define RTW_HEADER_rt_powd_snf_h_
#include "rtwtypes.h"

extern real_T rt_powd_snf(real_T u0, real_T u1);

#endif                                 /* RTW_HEADER_rt_powd_snf_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
