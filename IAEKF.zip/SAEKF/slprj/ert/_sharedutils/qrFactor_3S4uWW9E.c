/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: qrFactor_3S4uWW9E.c
 *
 * Code generated for Simulink model 'IAEKF'.
 *
 * Model version                  : 5.36
 * Simulink Coder version         : 9.6 (R2021b) 14-May-2021
 * C/C++ source code generated on : Thu Jun  1 21:51:50 2023
 */

#include "rtwtypes.h"
#include <math.h>
#include "rt_hypotd_snf.h"
#include "xgemv_UGmxVAQ3.h"
#include "xgerc_gmGrq1Dc.h"
#include "xnrm2_mLSAyvqi.h"
#include "qrFactor_3S4uWW9E.h"

/* Function for MATLAB Function: '<S22>/Correct' */
void qrFactor_3S4uWW9E(const real_T A[9], real_T S[9], const real_T Ns[3])
{
  real_T b_A[12];
  real_T y[9];
  real_T work[3];
  real_T atmp;
  real_T beta1;
  real_T tau_idx_0;
  int32_T aoffset;
  int32_T coffset;
  int32_T exitg1;
  int32_T knt;
  int32_T lastc;
  for (lastc = 0; lastc < 3; lastc++) {
    coffset = lastc * 3;
    for (knt = 0; knt < 3; knt++) {
      aoffset = knt * 3;
      y[coffset + knt] = ((S[aoffset + 1] * A[lastc + 3]) + (S[aoffset] *
        A[lastc])) + (S[aoffset + 2] * A[lastc + 6]);
    }
  }

  for (knt = 0; knt < 3; knt++) {
    lastc = knt * 4;
    b_A[lastc] = y[3 * knt];
    b_A[lastc + 1] = y[(3 * knt) + 1];
    b_A[lastc + 2] = y[(3 * knt) + 2];
    b_A[lastc + 3] = Ns[knt];
    work[knt] = 0.0;
  }

  atmp = b_A[0];
  tau_idx_0 = 0.0;
  beta1 = xnrm2_mLSAyvqi(3, b_A, 2);
  if (beta1 != 0.0) {
    beta1 = rt_hypotd_snf(b_A[0], beta1);
    if (b_A[0] >= 0.0) {
      beta1 = -beta1;
    }

    if (fabs(beta1) < 1.0020841800044864E-292) {
      knt = -1;
      do {
        knt++;
        for (lastc = 1; lastc < 4; lastc++) {
          b_A[lastc] *= 9.9792015476736E+291;
        }

        beta1 *= 9.9792015476736E+291;
        atmp *= 9.9792015476736E+291;
      } while (!(fabs(beta1) >= 1.0020841800044864E-292));

      beta1 = rt_hypotd_snf(atmp, xnrm2_mLSAyvqi(3, b_A, 2));
      if (atmp >= 0.0) {
        beta1 = -beta1;
      }

      tau_idx_0 = (beta1 - atmp) / beta1;
      atmp = 1.0 / (atmp - beta1);
      for (lastc = 1; lastc < 4; lastc++) {
        b_A[lastc] *= atmp;
      }

      for (lastc = 0; lastc <= knt; lastc++) {
        beta1 *= 1.0020841800044864E-292;
      }

      atmp = beta1;
    } else {
      tau_idx_0 = (beta1 - b_A[0]) / beta1;
      atmp = 1.0 / (b_A[0] - beta1);
      for (knt = 1; knt < 4; knt++) {
        b_A[knt] *= atmp;
      }

      atmp = beta1;
    }
  }

  b_A[0] = 1.0;
  if (tau_idx_0 != 0.0) {
    boolean_T exitg2;
    knt = 4;
    lastc = 3;
    while ((knt > 0) && (b_A[lastc] == 0.0)) {
      knt--;
      lastc--;
    }

    lastc = 2;
    exitg2 = false;
    while ((!exitg2) && (lastc > 0)) {
      coffset = ((lastc - 1) * 4) + 4;
      aoffset = coffset;
      do {
        exitg1 = 0;
        if ((aoffset + 1) <= (coffset + knt)) {
          if (b_A[aoffset] != 0.0) {
            exitg1 = 1;
          } else {
            aoffset++;
          }
        } else {
          lastc--;
          exitg1 = 2;
        }
      } while (exitg1 == 0);

      if (exitg1 == 1) {
        exitg2 = true;
      }
    }
  } else {
    knt = 0;
    lastc = 0;
  }

  if (knt > 0) {
    xgemv_UGmxVAQ3(knt, lastc, b_A, 5, b_A, 1, work);
    xgerc_gmGrq1Dc(knt, lastc, -tau_idx_0, 1, work, b_A, 5);
  }

  b_A[0] = atmp;
  atmp = b_A[5];
  tau_idx_0 = 0.0;
  beta1 = xnrm2_mLSAyvqi(2, b_A, 7);
  if (beta1 != 0.0) {
    beta1 = rt_hypotd_snf(b_A[5], beta1);
    if (b_A[5] >= 0.0) {
      beta1 = -beta1;
    }

    if (fabs(beta1) < 1.0020841800044864E-292) {
      knt = -1;
      do {
        knt++;
        for (lastc = 6; lastc < 8; lastc++) {
          b_A[lastc] *= 9.9792015476736E+291;
        }

        beta1 *= 9.9792015476736E+291;
        atmp *= 9.9792015476736E+291;
      } while (!(fabs(beta1) >= 1.0020841800044864E-292));

      beta1 = rt_hypotd_snf(atmp, xnrm2_mLSAyvqi(2, b_A, 7));
      if (atmp >= 0.0) {
        beta1 = -beta1;
      }

      tau_idx_0 = (beta1 - atmp) / beta1;
      atmp = 1.0 / (atmp - beta1);
      for (lastc = 6; lastc < 8; lastc++) {
        b_A[lastc] *= atmp;
      }

      for (lastc = 0; lastc <= knt; lastc++) {
        beta1 *= 1.0020841800044864E-292;
      }

      atmp = beta1;
    } else {
      tau_idx_0 = (beta1 - b_A[5]) / beta1;
      atmp = 1.0 / (b_A[5] - beta1);
      for (knt = 6; knt < 8; knt++) {
        b_A[knt] *= atmp;
      }

      atmp = beta1;
    }
  }

  b_A[5] = 1.0;
  if (tau_idx_0 != 0.0) {
    knt = 3;
    lastc = 7;
    while ((knt > 0) && (b_A[lastc] == 0.0)) {
      knt--;
      lastc--;
    }

    lastc = 1;
    aoffset = 9;
    do {
      exitg1 = 0;
      if ((aoffset + 1) <= (9 + knt)) {
        if (b_A[aoffset] != 0.0) {
          exitg1 = 1;
        } else {
          aoffset++;
        }
      } else {
        lastc = 0;
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  } else {
    knt = 0;
    lastc = 0;
  }

  if (knt > 0) {
    xgemv_UGmxVAQ3(knt, lastc, b_A, 10, b_A, 6, work);
    xgerc_gmGrq1Dc(knt, lastc, -tau_idx_0, 6, work, b_A, 10);
  }

  b_A[5] = atmp;
  atmp = b_A[10];
  beta1 = xnrm2_mLSAyvqi(1, b_A, 12);
  if (beta1 != 0.0) {
    beta1 = rt_hypotd_snf(b_A[10], beta1);
    if (b_A[10] >= 0.0) {
      beta1 = -beta1;
    }

    if (fabs(beta1) < 1.0020841800044864E-292) {
      knt = -1;
      do {
        knt++;
        for (lastc = 11; lastc < 12; lastc++) {
          b_A[lastc] *= 9.9792015476736E+291;
        }

        beta1 *= 9.9792015476736E+291;
        atmp *= 9.9792015476736E+291;
      } while (!(fabs(beta1) >= 1.0020841800044864E-292));

      beta1 = rt_hypotd_snf(atmp, xnrm2_mLSAyvqi(1, b_A, 12));
      if (atmp >= 0.0) {
        beta1 = -beta1;
      }

      atmp = 1.0 / (atmp - beta1);
      for (lastc = 11; lastc < 12; lastc++) {
        b_A[lastc] *= atmp;
      }

      for (lastc = 0; lastc <= knt; lastc++) {
        beta1 *= 1.0020841800044864E-292;
      }

      atmp = beta1;
    } else {
      atmp = 1.0 / (b_A[10] - beta1);
      for (knt = 11; knt < 12; knt++) {
        b_A[knt] *= atmp;
      }

      atmp = beta1;
    }
  }

  b_A[10] = atmp;
  y[0] = b_A[0];
  for (knt = 1; (knt + 1) < 4; knt++) {
    y[knt] = 0.0;
  }

  for (knt = 0; knt < 2; knt++) {
    y[knt + 3] = b_A[knt + 4];
  }

  for (knt = 2; (knt + 1) < 4; knt++) {
    y[knt + 3] = 0.0;
  }

  for (knt = 0; knt < 3; knt++) {
    y[knt + 6] = b_A[knt + 8];
  }

  for (knt = 0; knt < 3; knt++) {
    S[3 * knt] = y[knt];
    S[(3 * knt) + 1] = y[knt + 3];
    S[(3 * knt) + 2] = y[knt + 6];
  }
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
