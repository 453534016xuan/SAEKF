/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: batteryStateFcn.c
 *
 * Code generated for Simulink model 'IAEKF'.
 *
 * Model version                  : 5.37
 * Simulink Coder version         : 9.6 (R2021b) 14-May-2021
 * C/C++ source code generated on : Fri Jun  2 18:55:59 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objective: MISRA C:2012 guidelines
 * Validation result: Not run
 */

#include "batteryStateFcn.h"

/* Include model header file for global data */
#include "IAEKF.h"
#include "IAEKF_private.h"
#include "look1_binlxpw.h"

/* Output and update for Simulink Function: '<S7>/Simulink Function - State Transition Function2' */
void batteryStateFcn(const real_T rtu_x[3], real_T rty_xNext[3])
{
  real_T rtb_tau1;
  real_T rtb_tau2;

  /* Lookup_n-D: '<S21>/tau1' incorporates:
   *  SignalConversion generated from: '<S21>/x'
   */
  rtb_tau1 = look1_binlxpw(rtu_x[0], rtCP_tau1_bp01Data, rtCP_tau1_tableData,
    10U);

  /* Lookup_n-D: '<S21>/tau2' incorporates:
   *  SignalConversion generated from: '<S21>/x'
   */
  rtb_tau2 = look1_binlxpw(rtu_x[0], rtCP_tau2_bp01Data, rtCP_tau2_tableData,
    10U);

  /* MATLAB Function: '<S21>/f(x,u)' incorporates:
   *  Lookup_n-D: '<S21>/R1'
   *  Lookup_n-D: '<S21>/R2'
   *  SignalConversion generated from: '<S21>/Current'
   *  SignalConversion generated from: '<S21>/x'
   */
  rty_xNext[0] = (-IAEKF_B.Gain) / 5040.0;
  rty_xNext[1] = ((-1.0 / rtb_tau1) * rtu_x[1]) + (IAEKF_B.Gain / (rtb_tau1 /
    look1_binlxpw(rtu_x[0], rtCP_R1_bp01Data, rtCP_R1_tableData, 10U)));
  rty_xNext[2] = ((-1.0 / rtb_tau2) * rtu_x[2]) + (IAEKF_B.Gain / (rtb_tau2 /
    look1_binlxpw(rtu_x[0], rtCP_R2_bp01Data, rtCP_R2_tableData, 10U)));

  /* SignalConversion generated from: '<S21>/xNext' incorporates:
   *  Constant: '<S21>/Constant'
   *  Product: '<S21>/Product'
   *  SignalConversion generated from: '<S21>/x'
   *  Sum: '<S21>/Add'
   */
  rty_xNext[0] = (rty_xNext[0] * 0.5) + rtu_x[0];
  rty_xNext[1] = (rty_xNext[1] * 0.5) + rtu_x[1];
  rty_xNext[2] = (rty_xNext[2] * 0.5) + rtu_x[2];
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
