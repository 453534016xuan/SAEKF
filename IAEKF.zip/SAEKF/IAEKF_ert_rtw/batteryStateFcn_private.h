/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: batteryStateFcn_private.h
 *
 * Code generated for Simulink model 'IAEKF'.
 *
 * Model version                  : 5.37
 * Simulink Coder version         : 9.6 (R2021b) 14-May-2021
 * C/C++ source code generated on : Fri Jun  2 18:55:59 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objective: MISRA C:2012 guidelines
 * Validation result: Not run
 */

#ifndef RTW_HEADER_batteryStateFcn_private_h_
#define RTW_HEADER_batteryStateFcn_private_h_
#ifndef IAEKF_COMMON_INCLUDES_
#define IAEKF_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* IAEKF_COMMON_INCLUDES_ */
#endif                               /* RTW_HEADER_batteryStateFcn_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
