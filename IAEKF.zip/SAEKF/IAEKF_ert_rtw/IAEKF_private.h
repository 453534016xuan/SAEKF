/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: IAEKF_private.h
 *
 * Code generated for Simulink model 'IAEKF'.
 *
 * Model version                  : 5.37
 * Simulink Coder version         : 9.6 (R2021b) 14-May-2021
 * C/C++ source code generated on : Fri Jun  2 18:55:59 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objective: MISRA C:2012 guidelines
 * Validation result: Not run
 */

#ifndef RTW_HEADER_IAEKF_private_h_
#define RTW_HEADER_IAEKF_private_h_
#include "rtwtypes.h"

extern const real_T rtCP_pooled_5MAhcG7NgcZd[11];
extern const real_T rtCP_pooled_RgruezMvRTdd[11];
extern const real_T rtCP_pooled_yrNquG8sDbbB[11];
extern const real_T rtCP_pooled_OLsxUNhMCzqV[11];
extern const real_T rtCP_pooled_95OXhvwVWL8f[11];
extern const real_T rtCP_pooled_VwIX8DdjODTx[11];
extern const real_T rtCP_pooled_GKWr42kcmW0O[11];
extern const real_T rtCP_pooled_T7LJKz0qDStL[9];
extern const real_T rtCP_pooled_ymg0gvPA6wrI[9];

#define rtCP_Em_tableData              rtCP_pooled_5MAhcG7NgcZd  /* Expression: Em
                                                                  * Referenced by: '<S20>/Em'
                                                                  */
#define rtCP_Em_bp01Data               rtCP_pooled_RgruezMvRTdd  /* Expression: SOC_LUT
                                                                  * Referenced by: '<S20>/Em'
                                                                  */
#define rtCP_R0_tableData              rtCP_pooled_yrNquG8sDbbB  /* Expression: R0
                                                                  * Referenced by: '<S20>/R0'
                                                                  */
#define rtCP_R0_bp01Data               rtCP_pooled_RgruezMvRTdd  /* Expression: SOC_LUT
                                                                  * Referenced by: '<S20>/R0'
                                                                  */
#define rtCP_R1_tableData              rtCP_pooled_OLsxUNhMCzqV  /* Expression: R1
                                                                  * Referenced by: '<S21>/R1'
                                                                  */
#define rtCP_R1_bp01Data               rtCP_pooled_RgruezMvRTdd  /* Expression: SOC_LUT
                                                                  * Referenced by: '<S21>/R1'
                                                                  */
#define rtCP_R2_tableData              rtCP_pooled_95OXhvwVWL8f  /* Expression: R2
                                                                  * Referenced by: '<S21>/R2'
                                                                  */
#define rtCP_R2_bp01Data               rtCP_pooled_RgruezMvRTdd  /* Expression: SOC_LUT
                                                                  * Referenced by: '<S21>/R2'
                                                                  */
#define rtCP_tau1_tableData            rtCP_pooled_VwIX8DdjODTx  /* Expression: t1
                                                                  * Referenced by: '<S21>/tau1'
                                                                  */
#define rtCP_tau1_bp01Data             rtCP_pooled_RgruezMvRTdd  /* Expression: SOC_LUT
                                                                  * Referenced by: '<S21>/tau1'
                                                                  */
#define rtCP_tau2_tableData            rtCP_pooled_GKWr42kcmW0O  /* Expression: t2
                                                                  * Referenced by: '<S21>/tau2'
                                                                  */
#define rtCP_tau2_bp01Data             rtCP_pooled_RgruezMvRTdd  /* Expression: SOC_LUT
                                                                  * Referenced by: '<S21>/tau2'
                                                                  */
#define rtCP_R0Table_tableData         rtCP_pooled_yrNquG8sDbbB  /* Expression: [0.10349
                                                                    0.092719
                                                                    0.090637
                                                                    0.088544
                                                                    0.087522
                                                                    0.086408
                                                                    0.087028
                                                                    0.087722
                                                                    0.089617
                                                                    0.093538
                                                                    0.13707
                                                                    ]
                                                                  * Referenced by: '<S10>/R0 Table'
                                                                  */
#define rtCP_R0Table_bp01Data          rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S10>/R0 Table'
                                                                  */
#define rtCP_R1Table_tableData         rtCP_pooled_OLsxUNhMCzqV  /* Expression: [0.0025632
                                                                    1.64E-03
                                                                    0.0072182
                                                                    0.011417
                                                                    0.01036
                                                                    0.010416
                                                                    0.0087726
                                                                    0.010169
                                                                    0.011098
                                                                    0.002717
                                                                    0.033102
                                                                    ]
                                                                  * Referenced by: '<S10>/R1 Table'
                                                                  */
#define rtCP_R1Table_bp01Data          rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S10>/R1 Table'
                                                                  */
#define rtCP_R2Table_tableData         rtCP_pooled_95OXhvwVWL8f  /* Expression: [0.0077539
                                                                    0.011224
                                                                    0.011342
                                                                    9.05E-03
                                                                    4.58E-03
                                                                    0.00094137
                                                                    0.0015331
                                                                    0.0011701
                                                                    1.41E-03
                                                                    0.010584
                                                                    0.012872
                                                                    ]
                                                                  * Referenced by: '<S10>/R2 Table'
                                                                  */
#define rtCP_R2Table_bp01Data          rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S10>/R2 Table'
                                                                  */
#define rtCP_t1Table_tableData         rtCP_pooled_VwIX8DdjODTx  /* Expression: [5.7631
                                                                    5.0267
                                                                    12.333
                                                                    26.478
                                                                    23.212
                                                                    24.642
                                                                    27.825
                                                                    27.505
                                                                    30.924
                                                                    5.7617
                                                                    89.004
                                                                    ]
                                                                  * Referenced by: '<S10>/t1 Table'
                                                                  */
#define rtCP_t1Table_bp01Data          rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S10>/t1 Table'
                                                                  */
#define rtCP_t2Table_tableData         rtCP_pooled_GKWr42kcmW0O  /* Expression: [29.2
                                                                    54.0272
                                                                    57.54
                                                                    53.14
                                                                    25.4577
                                                                    5.53513
                                                                    6.0527
                                                                    4.2824
                                                                    5.3808
                                                                    34.853
                                                                    18.0852
                                                                    ]
                                                                  * Referenced by: '<S10>/t2 Table'
                                                                  */
#define rtCP_t2Table_bp01Data          rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S10>/t2 Table'
                                                                  */
#define rtCP_R0Table_tableData_k       rtCP_pooled_yrNquG8sDbbB  /* Expression: [0.10349
                                                                    0.092719
                                                                    0.090637
                                                                    0.088544
                                                                    0.087522
                                                                    0.086408
                                                                    0.087028
                                                                    0.087722
                                                                    0.089617
                                                                    0.093538
                                                                    0.13707
                                                                    ]
                                                                  * Referenced by: '<S30>/R0 Table'
                                                                  */
#define rtCP_R0Table_bp01Data_o        rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S30>/R0 Table'
                                                                  */
#define rtCP_R1Table_tableData_a       rtCP_pooled_OLsxUNhMCzqV  /* Expression: [0.0025632
                                                                    1.64E-03
                                                                    0.0072182
                                                                    0.011417
                                                                    0.01036
                                                                    0.010416
                                                                    0.0087726
                                                                    0.010169
                                                                    0.011098
                                                                    0.002717
                                                                    0.033102
                                                                    ]
                                                                  * Referenced by: '<S30>/R1 Table'
                                                                  */
#define rtCP_R1Table_bp01Data_n        rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S30>/R1 Table'
                                                                  */
#define rtCP_R2Table_tableData_a       rtCP_pooled_95OXhvwVWL8f  /* Expression: [0.0077539
                                                                    0.011224
                                                                    0.011342
                                                                    9.05E-03
                                                                    4.58E-03
                                                                    0.00094137
                                                                    0.0015331
                                                                    0.0011701
                                                                    1.41E-03
                                                                    0.010584
                                                                    0.012872
                                                                    ]
                                                                  * Referenced by: '<S30>/R2 Table'
                                                                  */
#define rtCP_R2Table_bp01Data_c        rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S30>/R2 Table'
                                                                  */
#define rtCP_t1Table_tableData_j       rtCP_pooled_VwIX8DdjODTx  /* Expression: [5.7631
                                                                    5.0267
                                                                    12.333
                                                                    26.478
                                                                    23.212
                                                                    24.642
                                                                    27.825
                                                                    27.505
                                                                    30.924
                                                                    5.7617
                                                                    89.004
                                                                    ]
                                                                  * Referenced by: '<S30>/t1 Table'
                                                                  */
#define rtCP_t1Table_bp01Data_m        rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S30>/t1 Table'
                                                                  */
#define rtCP_t2Table_tableData_a       rtCP_pooled_GKWr42kcmW0O  /* Expression: [29.2
                                                                    54.0272
                                                                    57.54
                                                                    53.14
                                                                    25.4577
                                                                    5.53513
                                                                    6.0527
                                                                    4.2824
                                                                    5.3808
                                                                    34.853
                                                                    18.0852
                                                                    ]
                                                                  * Referenced by: '<S30>/t2 Table'
                                                                  */
#define rtCP_t2Table_bp01Data_m        rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S30>/t2 Table'
                                                                  */
#define rtCP_R0Table_tableData_kd      rtCP_pooled_yrNquG8sDbbB  /* Expression: [0.10349
                                                                    0.092719
                                                                    0.090637
                                                                    0.088544
                                                                    0.087522
                                                                    0.086408
                                                                    0.087028
                                                                    0.087722
                                                                    0.089617
                                                                    0.093538
                                                                    0.13707
                                                                    ]
                                                                  * Referenced by: '<S18>/R0 Table'
                                                                  */
#define rtCP_R0Table_bp01Data_k        rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S18>/R0 Table'
                                                                  */
#define rtCP_R1Table_tableData_h       rtCP_pooled_OLsxUNhMCzqV  /* Expression: [0.0025632
                                                                    1.64E-03
                                                                    0.0072182
                                                                    0.011417
                                                                    0.01036
                                                                    0.010416
                                                                    0.0087726
                                                                    0.010169
                                                                    0.011098
                                                                    0.002717
                                                                    0.033102
                                                                    ]
                                                                  * Referenced by: '<S18>/R1 Table'
                                                                  */
#define rtCP_R1Table_bp01Data_l        rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S18>/R1 Table'
                                                                  */
#define rtCP_R2Table_tableData_i       rtCP_pooled_95OXhvwVWL8f  /* Expression: [0.0077539
                                                                    0.011224
                                                                    0.011342
                                                                    9.05E-03
                                                                    4.58E-03
                                                                    0.00094137
                                                                    0.0015331
                                                                    0.0011701
                                                                    1.41E-03
                                                                    0.010584
                                                                    0.012872
                                                                    ]
                                                                  * Referenced by: '<S18>/R2 Table'
                                                                  */
#define rtCP_R2Table_bp01Data_h        rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S18>/R2 Table'
                                                                  */
#define rtCP_t1Table_tableData_b       rtCP_pooled_VwIX8DdjODTx  /* Expression: [5.7631
                                                                    5.0267
                                                                    12.333
                                                                    26.478
                                                                    23.212
                                                                    24.642
                                                                    27.825
                                                                    27.505
                                                                    30.924
                                                                    5.7617
                                                                    89.004
                                                                    ]
                                                                  * Referenced by: '<S18>/t1 Table'
                                                                  */
#define rtCP_t1Table_bp01Data_h        rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S18>/t1 Table'
                                                                  */
#define rtCP_t2Table_tableData_e       rtCP_pooled_GKWr42kcmW0O  /* Expression: [29.2
                                                                    54.0272
                                                                    57.54
                                                                    53.14
                                                                    25.4577
                                                                    5.53513
                                                                    6.0527
                                                                    4.2824
                                                                    5.3808
                                                                    34.853
                                                                    18.0852
                                                                    ]
                                                                  * Referenced by: '<S18>/t2 Table'
                                                                  */
#define rtCP_t2Table_bp01Data_c        rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S18>/t2 Table'
                                                                  */
#define rtCP_R0Table_tableData_d       rtCP_pooled_yrNquG8sDbbB  /* Expression: [0.10349
                                                                    0.092719
                                                                    0.090637
                                                                    0.088544
                                                                    0.087522
                                                                    0.086408
                                                                    0.087028
                                                                    0.087722
                                                                    0.089617
                                                                    0.093538
                                                                    0.13707
                                                                    ]
                                                                  * Referenced by: '<S16>/R0 Table'
                                                                  */
#define rtCP_R0Table_bp01Data_e        rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S16>/R0 Table'
                                                                  */
#define rtCP_R1Table_tableData_j       rtCP_pooled_OLsxUNhMCzqV  /* Expression: [0.0025632
                                                                    1.64E-03
                                                                    0.0072182
                                                                    0.011417
                                                                    0.01036
                                                                    0.010416
                                                                    0.0087726
                                                                    0.010169
                                                                    0.011098
                                                                    0.002717
                                                                    0.033102
                                                                    ]
                                                                  * Referenced by: '<S16>/R1 Table'
                                                                  */
#define rtCP_R1Table_bp01Data_j        rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S16>/R1 Table'
                                                                  */
#define rtCP_R2Table_tableData_iv      rtCP_pooled_95OXhvwVWL8f  /* Expression: [0.0077539
                                                                    0.011224
                                                                    0.011342
                                                                    9.05E-03
                                                                    4.58E-03
                                                                    0.00094137
                                                                    0.0015331
                                                                    0.0011701
                                                                    1.41E-03
                                                                    0.010584
                                                                    0.012872
                                                                    ]
                                                                  * Referenced by: '<S16>/R2 Table'
                                                                  */
#define rtCP_R2Table_bp01Data_a        rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S16>/R2 Table'
                                                                  */
#define rtCP_t1Table_tableData_m       rtCP_pooled_VwIX8DdjODTx  /* Expression: [5.7631
                                                                    5.0267
                                                                    12.333
                                                                    26.478
                                                                    23.212
                                                                    24.642
                                                                    27.825
                                                                    27.505
                                                                    30.924
                                                                    5.7617
                                                                    89.004
                                                                    ]
                                                                  * Referenced by: '<S16>/t1 Table'
                                                                  */
#define rtCP_t1Table_bp01Data_mt       rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S16>/t1 Table'
                                                                  */
#define rtCP_t2Table_tableData_h       rtCP_pooled_GKWr42kcmW0O  /* Expression: [29.2
                                                                    54.0272
                                                                    57.54
                                                                    53.14
                                                                    25.4577
                                                                    5.53513
                                                                    6.0527
                                                                    4.2824
                                                                    5.3808
                                                                    34.853
                                                                    18.0852
                                                                    ]
                                                                  * Referenced by: '<S16>/t2 Table'
                                                                  */
#define rtCP_t2Table_bp01Data_e        rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S16>/t2 Table'
                                                                  */
#define rtCP_R0Table_tableData_j       rtCP_pooled_yrNquG8sDbbB  /* Expression: [0.10349
                                                                    0.092719
                                                                    0.090637
                                                                    0.088544
                                                                    0.087522
                                                                    0.086408
                                                                    0.087028
                                                                    0.087722
                                                                    0.089617
                                                                    0.093538
                                                                    0.13707
                                                                    ]
                                                                  * Referenced by: '<S14>/R0 Table'
                                                                  */
#define rtCP_R0Table_bp01Data_f        rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S14>/R0 Table'
                                                                  */
#define rtCP_R1Table_tableData_l       rtCP_pooled_OLsxUNhMCzqV  /* Expression: [0.0025632
                                                                    1.64E-03
                                                                    0.0072182
                                                                    0.011417
                                                                    0.01036
                                                                    0.010416
                                                                    0.0087726
                                                                    0.010169
                                                                    0.011098
                                                                    0.002717
                                                                    0.033102
                                                                    ]
                                                                  * Referenced by: '<S14>/R1 Table'
                                                                  */
#define rtCP_R1Table_bp01Data_c        rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S14>/R1 Table'
                                                                  */
#define rtCP_R2Table_tableData_e       rtCP_pooled_95OXhvwVWL8f  /* Expression: [0.0077539
                                                                    0.011224
                                                                    0.011342
                                                                    9.05E-03
                                                                    4.58E-03
                                                                    0.00094137
                                                                    0.0015331
                                                                    0.0011701
                                                                    1.41E-03
                                                                    0.010584
                                                                    0.012872
                                                                    ]
                                                                  * Referenced by: '<S14>/R2 Table'
                                                                  */
#define rtCP_R2Table_bp01Data_p        rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S14>/R2 Table'
                                                                  */
#define rtCP_t1Table_tableData_k       rtCP_pooled_VwIX8DdjODTx  /* Expression: [5.7631
                                                                    5.0267
                                                                    12.333
                                                                    26.478
                                                                    23.212
                                                                    24.642
                                                                    27.825
                                                                    27.505
                                                                    30.924
                                                                    5.7617
                                                                    89.004
                                                                    ]
                                                                  * Referenced by: '<S14>/t1 Table'
                                                                  */
#define rtCP_t1Table_bp01Data_mo       rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S14>/t1 Table'
                                                                  */
#define rtCP_t2Table_tableData_n       rtCP_pooled_GKWr42kcmW0O  /* Expression: [29.2
                                                                    54.0272
                                                                    57.54
                                                                    53.14
                                                                    25.4577
                                                                    5.53513
                                                                    6.0527
                                                                    4.2824
                                                                    5.3808
                                                                    34.853
                                                                    18.0852
                                                                    ]
                                                                  * Referenced by: '<S14>/t2 Table'
                                                                  */
#define rtCP_t2Table_bp01Data_k        rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S14>/t2 Table'
                                                                  */
#define rtCP_R0Table_tableData_c       rtCP_pooled_yrNquG8sDbbB  /* Expression: [0.10349
                                                                    0.092719
                                                                    0.090637
                                                                    0.088544
                                                                    0.087522
                                                                    0.086408
                                                                    0.087028
                                                                    0.087722
                                                                    0.089617
                                                                    0.093538
                                                                    0.13707
                                                                    ]
                                                                  * Referenced by: '<S12>/R0 Table'
                                                                  */
#define rtCP_R0Table_bp01Data_m        rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S12>/R0 Table'
                                                                  */
#define rtCP_R1Table_tableData_hy      rtCP_pooled_OLsxUNhMCzqV  /* Expression: [0.0025632
                                                                    1.64E-03
                                                                    0.0072182
                                                                    0.011417
                                                                    0.01036
                                                                    0.010416
                                                                    0.0087726
                                                                    0.010169
                                                                    0.011098
                                                                    0.002717
                                                                    0.033102
                                                                    ]
                                                                  * Referenced by: '<S12>/R1 Table'
                                                                  */
#define rtCP_R1Table_bp01Data_d        rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S12>/R1 Table'
                                                                  */
#define rtCP_R2Table_tableData_b       rtCP_pooled_95OXhvwVWL8f  /* Expression: [0.0077539
                                                                    0.011224
                                                                    0.011342
                                                                    9.05E-03
                                                                    4.58E-03
                                                                    0.00094137
                                                                    0.0015331
                                                                    0.0011701
                                                                    1.41E-03
                                                                    0.010584
                                                                    0.012872
                                                                    ]
                                                                  * Referenced by: '<S12>/R2 Table'
                                                                  */
#define rtCP_R2Table_bp01Data_hh       rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S12>/R2 Table'
                                                                  */
#define rtCP_t1Table_tableData_d       rtCP_pooled_VwIX8DdjODTx  /* Expression: [5.7631
                                                                    5.0267
                                                                    12.333
                                                                    26.478
                                                                    23.212
                                                                    24.642
                                                                    27.825
                                                                    27.505
                                                                    30.924
                                                                    5.7617
                                                                    89.004
                                                                    ]
                                                                  * Referenced by: '<S12>/t1 Table'
                                                                  */
#define rtCP_t1Table_bp01Data_g        rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S12>/t1 Table'
                                                                  */
#define rtCP_t2Table_tableData_ne      rtCP_pooled_GKWr42kcmW0O  /* Expression: [29.2
                                                                    54.0272
                                                                    57.54
                                                                    53.14
                                                                    25.4577
                                                                    5.53513
                                                                    6.0527
                                                                    4.2824
                                                                    5.3808
                                                                    34.853
                                                                    18.0852
                                                                    ]
                                                                  * Referenced by: '<S12>/t2 Table'
                                                                  */
#define rtCP_t2Table_bp01Data_h        rtCP_pooled_RgruezMvRTdd  /* Expression: [0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1]
                                                                  * Referenced by: '<S12>/t2 Table'
                                                                  */
#define rtCP_Q_Value                   rtCP_pooled_T7LJKz0qDStL  /* Expression: p.Q
                                                                  * Referenced by: '<S19>/Q'
                                                                  */
#define rtCP_DataStoreMemoryP_InitialVa rtCP_pooled_ymg0gvPA6wrI /* Expression: p.InitialCovariance
                                                                  * Referenced by: '<S19>/DataStoreMemory - P'
                                                                  */
#endif                                 /* RTW_HEADER_IAEKF_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
