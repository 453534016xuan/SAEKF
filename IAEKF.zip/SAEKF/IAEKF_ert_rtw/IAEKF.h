/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: IAEKF.h
 *
 * Code generated for Simulink model 'IAEKF'.
 *
 * Model version                  : 5.37
 * Simulink Coder version         : 9.6 (R2021b) 14-May-2021
 * C/C++ source code generated on : Fri Jun  2 18:55:59 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objective: MISRA C:2012 guidelines
 * Validation result: Not run
 */

#ifndef RTW_HEADER_IAEKF_h_
#define RTW_HEADER_IAEKF_h_
#include <math.h>
#include <string.h>
#ifndef IAEKF_COMMON_INCLUDES_
#define IAEKF_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* IAEKF_COMMON_INCLUDES_ */

#include "IAEKF_types.h"

/* Child system includes */
#include "batteryMeasurementFcn_private.h"
#include "batteryMeasurementFcn.h"
#include "batteryStateFcn_private.h"
#include "batteryStateFcn.h"
#include "rt_nonfinite.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

/* Block signals (default storage) */
typedef struct {
  real_T Gain;                         /* '<S1>/Gain' */
} B_IAEKF_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T UnitDelay_DSTATE;             /* '<S2>/Unit Delay' */
  real_T UnitDelay_DSTATE_i;           /* '<S8>/Unit Delay' */
  real_T UnitDelay_DSTATE_n;           /* '<S6>/Unit Delay' */
  real_T UnitDelay_DSTATE_l;           /* '<S5>/Unit Delay' */
  real_T UnitDelay_DSTATE_c;           /* '<S4>/Unit Delay' */
  real_T UnitDelay_DSTATE_g;           /* '<S3>/Unit Delay' */
  real_T P[9];                         /* '<S19>/DataStoreMemory - P' */
  real_T x[3];                         /* '<S19>/DataStoreMemory - x' */
  real_T P_k1[9];                      /* '<S8>/MATLAB Function' */
  real_T Q[9];                         /* '<S8>/MATLAB Function' */
  real_T R;                            /* '<S8>/MATLAB Function' */
  real_T X_k1[3];                      /* '<S8>/MATLAB Function' */
  real_T P_k1_h[9];                    /* '<S6>/MATLAB Function' */
  real_T Q_i[9];                       /* '<S6>/MATLAB Function' */
  real_T R_c;                          /* '<S6>/MATLAB Function' */
  real_T q[3];                         /* '<S6>/MATLAB Function' */
  real_T r;                            /* '<S6>/MATLAB Function' */
  real_T X_k1_b[3];                    /* '<S6>/MATLAB Function' */
  real_T k;                            /* '<S6>/MATLAB Function' */
  real_T P_k1_n[9];                    /* '<S5>/MATLAB Function' */
  real_T Q_k[9];                       /* '<S5>/MATLAB Function' */
  real_T R_n;                          /* '<S5>/MATLAB Function' */
  real_T q_o[3];                       /* '<S5>/MATLAB Function' */
  real_T r_n;                          /* '<S5>/MATLAB Function' */
  real_T X_k1_a[3];                    /* '<S5>/MATLAB Function' */
  real_T k_e;                          /* '<S5>/MATLAB Function' */
  real_T P_k1_e[9];                    /* '<S4>/MATLAB Function' */
  real_T Q_a[9];                       /* '<S4>/MATLAB Function' */
  real_T R_m;                          /* '<S4>/MATLAB Function' */
  real_T q_k[3];                       /* '<S4>/MATLAB Function' */
  real_T r_g;                          /* '<S4>/MATLAB Function' */
  real_T X_k1_m[3];                    /* '<S4>/MATLAB Function' */
  real_T k_d;                          /* '<S4>/MATLAB Function' */
  real_T P_k1_eq[9];                   /* '<S3>/MATLAB Function' */
  real_T Q_g[9];                       /* '<S3>/MATLAB Function' */
  real_T R_f;                          /* '<S3>/MATLAB Function' */
  real_T q_n[3];                       /* '<S3>/MATLAB Function' */
  real_T r_p;                          /* '<S3>/MATLAB Function' */
  real_T X_k1_l[3];                    /* '<S3>/MATLAB Function' */
  real_T k_o;                          /* '<S3>/MATLAB Function' */
  real_T P_k1_d[9];                    /* '<S2>/MATLAB Function' */
  real_T Q_m[9];                       /* '<S2>/MATLAB Function' */
  real_T R_f2;                         /* '<S2>/MATLAB Function' */
  real_T q_a[3];                       /* '<S2>/MATLAB Function' */
  real_T r_j;                          /* '<S2>/MATLAB Function' */
  real_T X_k1_p[3];                    /* '<S2>/MATLAB Function' */
  real_T k_l;                          /* '<S2>/MATLAB Function' */
} DW_IAEKF_T;

/* External inputs (root inport signals with default storage) */
typedef struct {
  real_T Current;                      /* '<Root>/Current' */
  real_T Voltage;                      /* '<Root>/Voltage' */
} ExtU_IAEKF_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real_T SOC_SAEKF;                    /* '<Root>/SOC_SAEKF' */
  real_T SOC_EKF;                      /* '<Root>/SOC_EKF' */
  real_T SOC_IEKF;                     /* '<Root>/SOC_IEKF' */
  real_T SOC_SAEKF_08;                 /* '<Root>/SOC_SAEKF_08' */
  real_T SOC_SAEKF_06;                 /* '<Root>/SOC_SAEKF_06' */
  real_T SOC_SAEKF_04;                 /* '<Root>/SOC_SAEKF_04' */
  real_T SOC_SAEKF_02;                 /* '<Root>/SOC_SAEKF_02' */
} ExtY_IAEKF_T;

/* Real-time Model Data Structure */
struct tag_RTM_IAEKF_T {
  const char_T * volatile errorStatus;
};

/* Block signals (default storage) */
extern B_IAEKF_T IAEKF_B;

/* Block states (default storage) */
extern DW_IAEKF_T IAEKF_DW;

/* External inputs (root inport signals with default storage) */
extern ExtU_IAEKF_T IAEKF_U;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_IAEKF_T IAEKF_Y;

/* Model entry point functions */
extern void IAEKF_initialize(void);
extern void IAEKF_step(void);
extern void IAEKF_terminate(void);

/* Real-time Model object */
extern RT_MODEL_IAEKF_T *const IAEKF_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S3>/Scope' : Unused code path elimination
 * Block '<S4>/Scope' : Unused code path elimination
 * Block '<S5>/Scope' : Unused code path elimination
 * Block '<S6>/Scope' : Unused code path elimination
 * Block '<S22>/RegisterSimulinkFcn' : Unused code path elimination
 * Block '<S24>/RegisterSimulinkFcn' : Unused code path elimination
 * Block '<S19>/checkMeasurementFcn1Signals' : Unused code path elimination
 * Block '<S19>/checkStateTransitionFcnSignals' : Unused code path elimination
 * Block '<S7>/Scope' : Unused code path elimination
 * Block '<Root>/Scope' : Unused code path elimination
 * Block '<Root>/Scope1' : Unused code path elimination
 * Block '<Root>/Scope2' : Unused code path elimination
 * Block '<Root>/Scope3' : Unused code path elimination
 * Block '<Root>/Scope4' : Unused code path elimination
 * Block '<Root>/Scope5' : Unused code path elimination
 * Block '<Root>/Scope6' : Unused code path elimination
 * Block '<S19>/DataTypeConversion_Enable1' : Eliminate redundant data type conversion
 * Block '<S19>/DataTypeConversion_Q' : Eliminate redundant data type conversion
 * Block '<S19>/DataTypeConversion_R1' : Eliminate redundant data type conversion
 * Block '<S19>/DataTypeConversion_uMeas1' : Eliminate redundant data type conversion
 * Block '<S19>/DataTypeConversion_uState' : Eliminate redundant data type conversion
 * Block '<S19>/DataTypeConversion_y1' : Eliminate redundant data type conversion
 * Block '<S1>/Zero-Order Hold' : Eliminated since input and output rates are identical
 * Block '<S1>/Zero-Order Hold1' : Eliminated since input and output rates are identical
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'IAEKF'
 * '<S1>'   : 'IAEKF/ARM-Cortex STM32F103'
 * '<S2>'   : 'IAEKF/ARM-Cortex STM32F103/AEKF1'
 * '<S3>'   : 'IAEKF/ARM-Cortex STM32F103/AEKF_02'
 * '<S4>'   : 'IAEKF/ARM-Cortex STM32F103/AEKF_04'
 * '<S5>'   : 'IAEKF/ARM-Cortex STM32F103/AEKF_06'
 * '<S6>'   : 'IAEKF/ARM-Cortex STM32F103/AEKF_08'
 * '<S7>'   : 'IAEKF/ARM-Cortex STM32F103/EKF_simulink2'
 * '<S8>'   : 'IAEKF/ARM-Cortex STM32F103/IEKF'
 * '<S9>'   : 'IAEKF/ARM-Cortex STM32F103/AEKF1/MATLAB Function'
 * '<S10>'  : 'IAEKF/ARM-Cortex STM32F103/AEKF1/Subsystem1'
 * '<S11>'  : 'IAEKF/ARM-Cortex STM32F103/AEKF_02/MATLAB Function'
 * '<S12>'  : 'IAEKF/ARM-Cortex STM32F103/AEKF_02/Subsystem'
 * '<S13>'  : 'IAEKF/ARM-Cortex STM32F103/AEKF_04/MATLAB Function'
 * '<S14>'  : 'IAEKF/ARM-Cortex STM32F103/AEKF_04/Subsystem'
 * '<S15>'  : 'IAEKF/ARM-Cortex STM32F103/AEKF_06/MATLAB Function'
 * '<S16>'  : 'IAEKF/ARM-Cortex STM32F103/AEKF_06/Subsystem1'
 * '<S17>'  : 'IAEKF/ARM-Cortex STM32F103/AEKF_08/MATLAB Function'
 * '<S18>'  : 'IAEKF/ARM-Cortex STM32F103/AEKF_08/Subsystem'
 * '<S19>'  : 'IAEKF/ARM-Cortex STM32F103/EKF_simulink2/EKF'
 * '<S20>'  : 'IAEKF/ARM-Cortex STM32F103/EKF_simulink2/Simulink Function - Measurement Function2'
 * '<S21>'  : 'IAEKF/ARM-Cortex STM32F103/EKF_simulink2/Simulink Function - State Transition Function2'
 * '<S22>'  : 'IAEKF/ARM-Cortex STM32F103/EKF_simulink2/EKF/Correct1'
 * '<S23>'  : 'IAEKF/ARM-Cortex STM32F103/EKF_simulink2/EKF/Output'
 * '<S24>'  : 'IAEKF/ARM-Cortex STM32F103/EKF_simulink2/EKF/Predict'
 * '<S25>'  : 'IAEKF/ARM-Cortex STM32F103/EKF_simulink2/EKF/Correct1/Correct'
 * '<S26>'  : 'IAEKF/ARM-Cortex STM32F103/EKF_simulink2/EKF/Output/MATLAB Function'
 * '<S27>'  : 'IAEKF/ARM-Cortex STM32F103/EKF_simulink2/EKF/Predict/Predict'
 * '<S28>'  : 'IAEKF/ARM-Cortex STM32F103/EKF_simulink2/Simulink Function - State Transition Function2/f(x,u)'
 * '<S29>'  : 'IAEKF/ARM-Cortex STM32F103/IEKF/MATLAB Function'
 * '<S30>'  : 'IAEKF/ARM-Cortex STM32F103/IEKF/Subsystem1'
 */
#endif                                 /* RTW_HEADER_IAEKF_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
