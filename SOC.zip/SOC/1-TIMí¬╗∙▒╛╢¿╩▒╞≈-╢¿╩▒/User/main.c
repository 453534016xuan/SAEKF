#include "stm32f10x.h"
#include "bsp_led.h"
#include "bsp_TiMbase.h"
#include "bsp_adc.h"
#include "bsp_usart.h"
#include "./systick/bsp_SysTick.h"

#include <stddef.h>
#include <stdio.h>          
#include "IAEKF.h"                

volatile int IsrOverrun = 0;
volatile uint32_t time = 0; // ms ��ʱ���� 
float  Time = 0.0; // ms ��ʱ���� 
// ADC1ת���ĵ�ѹֵͨ��MDA��ʽ����SRAM
extern __IO uint16_t ADC_ConvertedValue[NOFCHANEL];

// �ֲ����������ڱ���ת�������ĵ�ѹֵ 	 
double ADC_ConvertedValueLocal[NOFCHANEL];        
double current;

/**
  * @brief  ������
  * @param  ��  
  * @retval ��
  */
	
int_T main(int_T argc, const char *argv[])
{
//	float modelBaseRate = 0.5;

	/* led �˿����� */ 
	LED_GPIO_Config();
	
	/*��ʱ����ʼ��*/
	BASIC_TIM_Init();
	
	/*ADC��ʼ��*/
	ADCx_Init();
	
	/*usart��ʼ��*/
	USART_Config();
	
	/* ����SysTick Ϊ1us�ж�һ�� */
	SysTick_Init();
	
  /* Initialize model */
  IAEKF_initialize();
	

	
	while (1) 
	{	
		/*ADCȡֵ*/
		ADC_ConvertedValueLocal[0] =(double) ADC_ConvertedValue[0]/4096*3.3;
		ADC_ConvertedValueLocal[3] =(double) ADC_ConvertedValue[2]/4096*3.3;
		current  =  -((2.5 - ADC_ConvertedValueLocal[0])/0.185);
		
		/*���ӽӿ�*/
		IAEKF_U.Current = current;
		IAEKF_U.Voltage = ADC_ConvertedValueLocal[2];
			
		/*����SOC*/
		 IAEKF_step();
		
		/*�������*/
		/*��ѹ����ʱ������*/
		printf("\r\n Time value = %.1f  \r\n",Time);		
		printf("\r\n CH0 value = %.3f  \r\n",ADC_ConvertedValueLocal[0]);
		printf("\r\n voltage  = %.3f  \r\n",ADC_ConvertedValueLocal[3]);
		printf("\r\n current  = %.2f  \r\n",current);
		
		/*SOC���ֵ*/
		printf("\r\n SOC_SAEKF  = %.4f  \r\n",IAEKF_Y.SOC_SAEKF);
		printf("\r\n SOC_EKF    = %.4f  \r\n",IAEKF_Y.SOC_EKF);
		printf("\r\n SOC_IEKF   = %.4f  \r\n",IAEKF_Y.SOC_IEKF);
		printf("\r\n SOC_SAEKF_08  = %.4f  \r\n",IAEKF_Y.SOC_SAEKF_08);
		printf("\r\n SOC_SAEKF_06  = %.4f  \r\n",IAEKF_Y.SOC_SAEKF_06);
		printf("\r\n SOC_SAEKF_04  = %.4f  \r\n",IAEKF_Y.SOC_SAEKF_04);
		printf("\r\n SOC_SAEKF_02  = %.4f  \r\n",IAEKF_Y.SOC_SAEKF_02);

		printf("\r\n\r\n");
		
		while(time <= 1000)
		{
			if ( time == 1000 ) /* 1000 * 1 ms = 1s ʱ�䵽 */
			{
				/* LED1 ȡ�� */      
				LED1_TOGGLE; 
			}        
		}
		time = 0;
		Time = Time + 1;
	}

}
/*********************************************END OF FILE**********************/

