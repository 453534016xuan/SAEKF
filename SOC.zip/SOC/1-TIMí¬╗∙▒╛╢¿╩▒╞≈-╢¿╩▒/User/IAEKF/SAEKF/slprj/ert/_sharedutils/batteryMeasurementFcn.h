/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: batteryMeasurementFcn.h
 *
 * Code generated for Simulink model 'IAEKF'.
 *
 * Model version                  : 5.37
 * Simulink Coder version         : 9.6 (R2021b) 14-May-2021
 * C/C++ source code generated on : Fri Jun  2 18:55:59 2023
 */

#ifndef RTW_HEADER_batteryMeasurementFcn_h_
#define RTW_HEADER_batteryMeasurementFcn_h_

/* Shared type includes */
#include "rtwtypes.h"

extern real_T batteryMeasurementFcn(const real_T rtu_x[3]);

#endif                                 /* RTW_HEADER_batteryMeasurementFcn_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
