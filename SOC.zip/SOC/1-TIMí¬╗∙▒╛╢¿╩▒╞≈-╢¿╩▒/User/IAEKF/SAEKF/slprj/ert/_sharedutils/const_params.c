/*
 * const_params.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "IAEKF".
 *
 * Model version              : 5.37
 * Simulink Coder version : 9.6 (R2021b) 14-May-2021
 * C source code generated on : Fri Jun  2 18:55:59 2023
 */
#include "rtwtypes.h"

extern const real_T rtCP_pooled_5MAhcG7NgcZd[11];
const real_T rtCP_pooled_5MAhcG7NgcZd[11] = { 1.3329, 1.3602, 1.3853, 1.4026,
  1.4209, 1.4404, 1.4612, 1.4815, 1.5057, 1.538, 1.672 } ;

extern const real_T rtCP_pooled_95OXhvwVWL8f[11];
const real_T rtCP_pooled_95OXhvwVWL8f[11] = { 0.0077539, 0.011224, 0.011342,
  0.00905, 0.00458, 0.00094137, 0.0015331, 0.0011701, 0.00141, 0.010584,
  0.012872 } ;

extern const real_T rtCP_pooled_CO0CwdLmDuIO[11];
const real_T rtCP_pooled_CO0CwdLmDuIO[11] = { 0.012012401, 0.010832112,
  0.021639144, 0.017320276, 0.008376286, 0.015055401, 0.010636841, 0.005430491,
  0.008364611, 0.012999147, 0.005430997 } ;

extern const real_T rtCP_pooled_GKWr42kcmW0O[11];
const real_T rtCP_pooled_GKWr42kcmW0O[11] = { 29.2, 54.0272, 57.54, 53.14,
  25.4577, 5.53513, 6.0527, 4.2824, 5.3808, 34.853, 18.0852 } ;

extern const real_T rtCP_pooled_LMZgobOy9FXG[11];
const real_T rtCP_pooled_LMZgobOy9FXG[11] = { 0.0682512674, 0.059119059,
  0.023817356, 0.031162129, 0.010140976, 0.01365695, 0.015818839, 0.009466583,
  0.010761756, 0.00687776, 0.038494814 } ;

extern const real_T rtCP_pooled_OLsxUNhMCzqV[11];
const real_T rtCP_pooled_OLsxUNhMCzqV[11] = { 0.0025632, 0.00164, 0.0072182,
  0.011417, 0.01036, 0.010416, 0.0087726, 0.010169, 0.011098, 0.002717, 0.033102
} ;

extern const real_T rtCP_pooled_RgruezMvRTdd[11];
const real_T rtCP_pooled_RgruezMvRTdd[11] = { 0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6,
  0.7, 0.8, 0.9, 1.0 } ;

extern const real_T rtCP_pooled_T7LJKz0qDStL[9];
const real_T rtCP_pooled_T7LJKz0qDStL[9] = { 0.01, 0.0, 0.0, 0.0, 0.01, 0.0, 0.0,
  0.0, 0.01 } ;

extern const real_T rtCP_pooled_VwIX8DdjODTx[11];
const real_T rtCP_pooled_VwIX8DdjODTx[11] = { 5.7631, 5.0267, 12.333, 26.478,
  23.212, 24.642, 27.825, 27.505, 30.924, 5.7617, 89.004 } ;

extern const real_T rtCP_pooled_bD8YfvFxM5p4[11];
const real_T rtCP_pooled_bD8YfvFxM5p4[11] = { 15.59966958, 48.213856081,
  107.3468155, 103.2952958, 50.83441168, 80.37671368, 54.1233142, 25.21293143,
  30.89171614, 31.55343003, 10.96408823 } ;

extern const real_T rtCP_pooled_hBGDLJu2vW08[11];
const real_T rtCP_pooled_hBGDLJu2vW08[11] = { 0.116573767, 0.099196851,
  0.10795042, 0.105455693, 0.095497492, 0.085013069, 0.093946797, 0.09647608,
  0.098431026, 0.103335577, 0.152437559 } ;

extern const real_T rtCP_pooled_kS7iGffgb6IS[11];
const real_T rtCP_pooled_kS7iGffgb6IS[11] = { 1.353832658, 1.365655741,
  1.408449735, 1.42263639, 1.422754361, 1.442874775, 1.459930246, 1.47937097,
  1.502778057, 1.534260666, 1.661172478 } ;

extern const real_T rtCP_pooled_kUdgfs4arYet[11];
const real_T rtCP_pooled_kUdgfs4arYet[11] = { 1519.5617542, 1051.2678904,
  195.2628249, 316.9422538, 54.88517261, 101.4289055, 64.62929295, 53.24855315,
  45.92453998, 28.41308775, 95.32471837 } ;

extern const real_T rtCP_pooled_ymg0gvPA6wrI[9];
const real_T rtCP_pooled_ymg0gvPA6wrI[9] = { 0.31622776601683794, 0.0, 0.0, 0.0,
  0.31622776601683794, 0.0, 0.0, 0.0, 0.31622776601683794 } ;

extern const real_T rtCP_pooled_yrNquG8sDbbB[11];
const real_T rtCP_pooled_yrNquG8sDbbB[11] = { 0.10349, 0.092719, 0.090637,
  0.088544, 0.087522, 0.086408, 0.087028, 0.087722, 0.089617, 0.093538, 0.13707
} ;
