/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: qrFactor_yMceNYiC.c
 *
 * Code generated for Simulink model 'IAEKF'.
 *
 * Model version                  : 5.36
 * Simulink Coder version         : 9.6 (R2021b) 14-May-2021
 * C/C++ source code generated on : Thu Jun  1 21:51:50 2023
 */

#include "rtwtypes.h"
#include <math.h>
#include "rt_hypotd_snf.h"
#include "xgemv_vstTrMTP.h"
#include "xgerc_mq4CkDh0.h"
#include "xnrm2_yvHqt3oe.h"
#include "qrFactor_yMceNYiC.h"

/* Function for MATLAB Function: '<S24>/Predict' */
void qrFactor_yMceNYiC(const real_T A[9], real_T S[9], const real_T Ns[9])
{
  real_T b_A[18];
  real_T y[9];
  real_T work[3];
  real_T atmp;
  real_T beta1;
  real_T tau_idx_0;
  int32_T aoffset;
  int32_T coffset;
  int32_T exitg1;
  int32_T knt;
  int32_T lastc;
  for (knt = 0; knt < 3; knt++) {
    coffset = knt * 3;
    for (lastc = 0; lastc < 3; lastc++) {
      aoffset = lastc * 3;
      y[coffset + lastc] = ((S[aoffset + 1] * A[knt + 3]) + (S[aoffset] * A[knt]))
        + (S[aoffset + 2] * A[knt + 6]);
    }
  }

  for (lastc = 0; lastc < 3; lastc++) {
    b_A[6 * lastc] = y[3 * lastc];
    b_A[(6 * lastc) + 3] = Ns[lastc];
    b_A[(6 * lastc) + 1] = y[(3 * lastc) + 1];
    b_A[(6 * lastc) + 4] = Ns[lastc + 3];
    b_A[(6 * lastc) + 2] = y[(3 * lastc) + 2];
    b_A[(6 * lastc) + 5] = Ns[lastc + 6];
    work[lastc] = 0.0;
  }

  atmp = b_A[0];
  tau_idx_0 = 0.0;
  beta1 = xnrm2_yvHqt3oe(5, b_A, 2);
  if (beta1 != 0.0) {
    beta1 = rt_hypotd_snf(b_A[0], beta1);
    if (b_A[0] >= 0.0) {
      beta1 = -beta1;
    }

    if (fabs(beta1) < 1.0020841800044864E-292) {
      knt = -1;
      do {
        knt++;
        for (lastc = 1; lastc < 6; lastc++) {
          b_A[lastc] *= 9.9792015476736E+291;
        }

        beta1 *= 9.9792015476736E+291;
        atmp *= 9.9792015476736E+291;
      } while (!(fabs(beta1) >= 1.0020841800044864E-292));

      beta1 = rt_hypotd_snf(atmp, xnrm2_yvHqt3oe(5, b_A, 2));
      if (atmp >= 0.0) {
        beta1 = -beta1;
      }

      tau_idx_0 = (beta1 - atmp) / beta1;
      atmp = 1.0 / (atmp - beta1);
      for (lastc = 1; lastc < 6; lastc++) {
        b_A[lastc] *= atmp;
      }

      for (lastc = 0; lastc <= knt; lastc++) {
        beta1 *= 1.0020841800044864E-292;
      }

      atmp = beta1;
    } else {
      tau_idx_0 = (beta1 - b_A[0]) / beta1;
      atmp = 1.0 / (b_A[0] - beta1);
      for (knt = 1; knt < 6; knt++) {
        b_A[knt] *= atmp;
      }

      atmp = beta1;
    }
  }

  b_A[0] = 1.0;
  if (tau_idx_0 != 0.0) {
    boolean_T exitg2;
    knt = 6;
    lastc = 5;
    while ((knt > 0) && (b_A[lastc] == 0.0)) {
      knt--;
      lastc--;
    }

    lastc = 2;
    exitg2 = false;
    while ((!exitg2) && (lastc > 0)) {
      coffset = ((lastc - 1) * 6) + 6;
      aoffset = coffset;
      do {
        exitg1 = 0;
        if ((aoffset + 1) <= (coffset + knt)) {
          if (b_A[aoffset] != 0.0) {
            exitg1 = 1;
          } else {
            aoffset++;
          }
        } else {
          lastc--;
          exitg1 = 2;
        }
      } while (exitg1 == 0);

      if (exitg1 == 1) {
        exitg2 = true;
      }
    }
  } else {
    knt = 0;
    lastc = 0;
  }

  if (knt > 0) {
    xgemv_vstTrMTP(knt, lastc, b_A, 7, b_A, 1, work);
    xgerc_mq4CkDh0(knt, lastc, -tau_idx_0, 1, work, b_A, 7);
  }

  b_A[0] = atmp;
  atmp = b_A[7];
  tau_idx_0 = 0.0;
  beta1 = xnrm2_yvHqt3oe(4, b_A, 9);
  if (beta1 != 0.0) {
    beta1 = rt_hypotd_snf(b_A[7], beta1);
    if (b_A[7] >= 0.0) {
      beta1 = -beta1;
    }

    if (fabs(beta1) < 1.0020841800044864E-292) {
      knt = -1;
      do {
        knt++;
        for (lastc = 8; lastc < 12; lastc++) {
          b_A[lastc] *= 9.9792015476736E+291;
        }

        beta1 *= 9.9792015476736E+291;
        atmp *= 9.9792015476736E+291;
      } while (!(fabs(beta1) >= 1.0020841800044864E-292));

      beta1 = rt_hypotd_snf(atmp, xnrm2_yvHqt3oe(4, b_A, 9));
      if (atmp >= 0.0) {
        beta1 = -beta1;
      }

      tau_idx_0 = (beta1 - atmp) / beta1;
      atmp = 1.0 / (atmp - beta1);
      for (lastc = 8; lastc < 12; lastc++) {
        b_A[lastc] *= atmp;
      }

      for (lastc = 0; lastc <= knt; lastc++) {
        beta1 *= 1.0020841800044864E-292;
      }

      atmp = beta1;
    } else {
      tau_idx_0 = (beta1 - b_A[7]) / beta1;
      atmp = 1.0 / (b_A[7] - beta1);
      for (knt = 8; knt < 12; knt++) {
        b_A[knt] *= atmp;
      }

      atmp = beta1;
    }
  }

  b_A[7] = 1.0;
  if (tau_idx_0 != 0.0) {
    knt = 5;
    lastc = 11;
    while ((knt > 0) && (b_A[lastc] == 0.0)) {
      knt--;
      lastc--;
    }

    lastc = 1;
    aoffset = 13;
    do {
      exitg1 = 0;
      if ((aoffset + 1) <= (13 + knt)) {
        if (b_A[aoffset] != 0.0) {
          exitg1 = 1;
        } else {
          aoffset++;
        }
      } else {
        lastc = 0;
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  } else {
    knt = 0;
    lastc = 0;
  }

  if (knt > 0) {
    xgemv_vstTrMTP(knt, lastc, b_A, 14, b_A, 8, work);
    xgerc_mq4CkDh0(knt, lastc, -tau_idx_0, 8, work, b_A, 14);
  }

  b_A[7] = atmp;
  atmp = b_A[14];
  beta1 = xnrm2_yvHqt3oe(3, b_A, 16);
  if (beta1 != 0.0) {
    beta1 = rt_hypotd_snf(b_A[14], beta1);
    if (b_A[14] >= 0.0) {
      beta1 = -beta1;
    }

    if (fabs(beta1) < 1.0020841800044864E-292) {
      knt = -1;
      do {
        knt++;
        for (lastc = 15; lastc < 18; lastc++) {
          b_A[lastc] *= 9.9792015476736E+291;
        }

        beta1 *= 9.9792015476736E+291;
        atmp *= 9.9792015476736E+291;
      } while (!(fabs(beta1) >= 1.0020841800044864E-292));

      beta1 = rt_hypotd_snf(atmp, xnrm2_yvHqt3oe(3, b_A, 16));
      if (atmp >= 0.0) {
        beta1 = -beta1;
      }

      atmp = 1.0 / (atmp - beta1);
      for (lastc = 15; lastc < 18; lastc++) {
        b_A[lastc] *= atmp;
      }

      for (lastc = 0; lastc <= knt; lastc++) {
        beta1 *= 1.0020841800044864E-292;
      }

      atmp = beta1;
    } else {
      atmp = 1.0 / (b_A[14] - beta1);
      for (knt = 15; knt < 18; knt++) {
        b_A[knt] *= atmp;
      }

      atmp = beta1;
    }
  }

  b_A[14] = atmp;
  y[0] = b_A[0];
  for (knt = 1; (knt + 1) < 4; knt++) {
    y[knt] = 0.0;
  }

  for (knt = 0; knt < 2; knt++) {
    y[knt + 3] = b_A[knt + 6];
  }

  for (knt = 2; (knt + 1) < 4; knt++) {
    y[knt + 3] = 0.0;
  }

  for (knt = 0; knt < 3; knt++) {
    y[knt + 6] = b_A[knt + 12];
  }

  for (knt = 0; knt < 3; knt++) {
    S[3 * knt] = y[knt];
    S[(3 * knt) + 1] = y[knt + 3];
    S[(3 * knt) + 2] = y[knt + 6];
  }
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
