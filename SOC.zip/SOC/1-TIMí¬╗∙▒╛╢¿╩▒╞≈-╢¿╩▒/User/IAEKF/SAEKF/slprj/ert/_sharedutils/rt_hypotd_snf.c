/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: rt_hypotd_snf.c
 *
 * Code generated for Simulink model 'IAEKF'.
 *
 * Model version                  : 5.36
 * Simulink Coder version         : 9.6 (R2021b) 14-May-2021
 * C/C++ source code generated on : Thu Jun  1 21:51:50 2023
 */

#include "rtwtypes.h"
#include <math.h>
#include "rt_nonfinite.h"
#include "rt_hypotd_snf.h"

real_T rt_hypotd_snf(real_T u0, real_T u1)
{
  real_T a;
  real_T y;
  a = fabs(u0);
  y = fabs(u1);
  if (a < y) {
    a /= y;
    y *= sqrt((a * a) + 1.0);
  } else if (a > y) {
    y /= a;
    y = sqrt((y * y) + 1.0) * a;
  } else if (!rtIsNaN(y)) {
    y = a * 1.4142135623730951;
  } else {
    /* no actions */
  }

  return y;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
