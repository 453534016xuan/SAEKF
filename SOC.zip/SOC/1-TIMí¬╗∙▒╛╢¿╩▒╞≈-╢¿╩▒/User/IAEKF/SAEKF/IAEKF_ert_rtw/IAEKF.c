/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: IAEKF.c
 *
 * Code generated for Simulink model 'IAEKF'.
 *
 * Model version                  : 5.37
 * Simulink Coder version         : 9.6 (R2021b) 14-May-2021
 * C/C++ source code generated on : Fri Jun  2 18:55:59 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objective: MISRA C:2012 guidelines
 * Validation result: Not run
 */

#include "IAEKF.h"
#include "IAEKF_private.h"
#include "look1_binlxpw.h"
#include "qrFactor_3S4uWW9E.h"
#include "qrFactor_yMceNYiC.h"
#include "rt_hypotd_snf.h"
#include "rt_powd_snf.h"
#include "trisolve_MxVysJHk.h"
#include "xnrm2_pxcAlubC.h"

/* Block signals (default storage) */
B_IAEKF_T IAEKF_B;

/* Block states (default storage) */
DW_IAEKF_T IAEKF_DW;

/* External inputs (root inport signals with default storage) */
ExtU_IAEKF_T IAEKF_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_IAEKF_T IAEKF_Y;

/* Real-time model */
static RT_MODEL_IAEKF_T IAEKF_M_;
RT_MODEL_IAEKF_T *const IAEKF_M = &IAEKF_M_;

/* Forward declaration for local functions */
static void EKFCorrectorAdditive_getMeasure(real_T Rs, const real_T x[3], const
  real_T S[9], real_T *zEstimated, real_T Pxy[3], real_T *Sy, real_T dHdx[3],
  real_T *Rsqrt);

/* Function for MATLAB Function: '<S22>/Correct' */
static void EKFCorrectorAdditive_getMeasure(real_T Rs, const real_T x[3], const
  real_T S[9], real_T *zEstimated, real_T Pxy[3], real_T *Sy, real_T dHdx[3],
  real_T *Rsqrt)
{
  real_T S_0[9];
  real_T A[4];
  real_T fState[3];
  real_T epsilon;
  real_T z;
  int32_T aoffset;
  int32_T k;
  int32_T knt;
  z = batteryMeasurementFcn(x);
  for (knt = 0; knt < 3; knt++) {
    real_T imz;
    fState[0] = x[0];
    fState[1] = x[1];
    fState[2] = x[2];
    epsilon = fmax(1.4901161193847656E-8, 1.4901161193847656E-8 * fabs(x[knt]));
    fState[knt] = x[knt] + epsilon;
    imz = batteryMeasurementFcn(fState);
    dHdx[knt] = (imz - z) / epsilon;
  }

  *Rsqrt = Rs;
  *zEstimated = batteryMeasurementFcn(x);
  for (knt = 0; knt < 3; knt++) {
    Pxy[knt] = 0.0;
    aoffset = knt * 3;
    z = 0.0;
    for (k = 0; k < 3; k++) {
      int32_T S_tmp;
      epsilon = dHdx[k];
      S_tmp = (3 * k) + knt;
      S_0[S_tmp] = 0.0;
      S_0[S_tmp] += S[knt] * S[k];
      S_0[S_tmp] += S[knt + 3] * S[k + 3];
      S_0[S_tmp] += S[knt + 6] * S[k + 6];
      z += S[aoffset + k] * epsilon;
      Pxy[knt] += S_0[S_tmp] * epsilon;
    }

    A[knt] = z;
  }

  A[3] = Rs;
  *Sy = A[0];
  z = xnrm2_pxcAlubC(3, A, 2);
  if (z != 0.0) {
    z = rt_hypotd_snf(A[0], z);
    if (A[0] >= 0.0) {
      z = -z;
    }

    if (fabs(z) < 1.0020841800044864E-292) {
      knt = -1;
      do {
        knt++;
        for (aoffset = 1; aoffset < 4; aoffset++) {
          A[aoffset] *= 9.9792015476736E+291;
        }

        z *= 9.9792015476736E+291;
        *Sy *= 9.9792015476736E+291;
      } while (!(fabs(z) >= 1.0020841800044864E-292));

      z = rt_hypotd_snf(*Sy, xnrm2_pxcAlubC(3, A, 2));
      if ((*Sy) >= 0.0) {
        z = -z;
      }

      for (aoffset = 0; aoffset <= knt; aoffset++) {
        z *= 1.0020841800044864E-292;
      }

      *Sy = z;
    } else {
      *Sy = z;
    }
  }
}

/* Model step function */
void IAEKF_step(void)
{
  real_T A[9];
  real_T A_0[9];
  real_T A_1[9];
  real_T P_kk1[9];
  real_T P_kk1_tmp[9];
  real_T H[3];
  real_T H_0[3];
  real_T K[3];
  real_T X_kk1[3];
  real_T X_kk1_tmp[3];
  real_T A_tmp;
  real_T H_tmp;
  real_T d;
  real_T e_out;
  real_T rtb_R0Table;
  real_T rtb_R0Table_mt;
  real_T rtb_R1Table;
  real_T rtb_R2Table;
  real_T v;
  int32_T A_tmp_0;
  int32_T b_I_tmp;
  int32_T i;
  int8_T b_I[9];

  /* Gain: '<S1>/Gain' incorporates:
   *  Inport: '<Root>/Current'
   */
  IAEKF_B.Gain = -IAEKF_U.Current;

  /* Lookup_n-D: '<S10>/R0 Table' incorporates:
   *  UnitDelay: '<S2>/Unit Delay'
   */
  rtb_R0Table = look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE, rtCP_R0Table_bp01Data,
    rtCP_R0Table_tableData, 10U);

  /* Lookup_n-D: '<S10>/R1 Table' incorporates:
   *  UnitDelay: '<S2>/Unit Delay'
   */
  rtb_R1Table = look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE, rtCP_R1Table_bp01Data,
    rtCP_R1Table_tableData, 10U);

  /* Lookup_n-D: '<S10>/R2 Table' incorporates:
   *  UnitDelay: '<S2>/Unit Delay'
   */
  rtb_R2Table = look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE, rtCP_R2Table_bp01Data,
    rtCP_R2Table_tableData, 10U);

  /* MATLAB Function: '<S2>/MATLAB Function' incorporates:
   *  Constant: '<S2>/Constant'
   *  Inport: '<Root>/Voltage'
   *  Lookup_n-D: '<S10>/t1 Table'
   *  Lookup_n-D: '<S10>/t2 Table'
   *  UnitDelay: '<S2>/Unit Delay'
   */
  /*  ȷ��״̬����͹۲���� */
  d = exp(-0.5 / look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE, rtCP_t1Table_bp01Data,
           rtCP_t1Table_tableData, 10U));
  A_tmp = exp(-0.5 / look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE,
    rtCP_t2Table_bp01Data, rtCP_t2Table_tableData, 10U));
  A[0] = 1.0;
  A[3] = 0.0;
  A[6] = 0.0;
  A[1] = 0.0;
  A[4] = d;
  A[7] = 0.0;
  A[2] = 0.0;
  A[5] = 0.0;
  A[8] = A_tmp;
  IAEKF_DW.UnitDelay_DSTATE = IAEKF_DW.X_k1_p[0];
  v = rt_powd_snf(IAEKF_DW.UnitDelay_DSTATE, 4.0);
  e_out = rt_powd_snf(IAEKF_DW.UnitDelay_DSTATE, 3.0);
  H_tmp = IAEKF_DW.UnitDelay_DSTATE * IAEKF_DW.UnitDelay_DSTATE;
  H[0] = ((((21.04 * v) - (39.16 * e_out)) + (H_tmp * 25.698)) - (6.698 *
           IAEKF_DW.UnitDelay_DSTATE)) + 0.6719;
  H[1] = -1.0;
  H[2] = -1.0;

  /*  ȷ��״̬�۲���󣬼�������� */
  /*  �������˲� */
  for (i = 0; i < 3; i++) {
    X_kk1_tmp[i] = 0.0;
    for (b_I_tmp = 0; b_I_tmp < 3; b_I_tmp++) {
      A_tmp_0 = (3 * b_I_tmp) + i;
      A_0[A_tmp_0] = 0.0;
      A_0[A_tmp_0] += IAEKF_DW.P_k1_d[3 * b_I_tmp] * A[i];
      A_0[A_tmp_0] += IAEKF_DW.P_k1_d[(3 * b_I_tmp) + 1] * A[i + 3];
      A_0[A_tmp_0] += IAEKF_DW.P_k1_d[(3 * b_I_tmp) + 2] * A[i + 6];
      X_kk1_tmp[i] += A[A_tmp_0] * IAEKF_DW.X_k1_p[b_I_tmp];
    }

    for (b_I_tmp = 0; b_I_tmp < 3; b_I_tmp++) {
      A_tmp_0 = (3 * b_I_tmp) + i;
      P_kk1_tmp[A_tmp_0] = 0.0;
      P_kk1_tmp[A_tmp_0] += A_0[i] * A[b_I_tmp];
      P_kk1_tmp[A_tmp_0] += A_0[i + 3] * A[b_I_tmp + 3];
      P_kk1_tmp[A_tmp_0] += A_0[i + 6] * A[b_I_tmp + 6];
    }
  }

  X_kk1[0] = (-9.92063492063492E-5 * IAEKF_B.Gain) + X_kk1_tmp[0];
  X_kk1[1] = (((1.0 - d) * rtb_R1Table) * IAEKF_B.Gain) + X_kk1_tmp[1];
  X_kk1[2] = (((1.0 - A_tmp) * rtb_R2Table) * IAEKF_B.Gain) + X_kk1_tmp[2];
  for (i = 0; i < 9; i++) {
    P_kk1[i] = P_kk1_tmp[i] + IAEKF_DW.Q_m[i];
  }

  rtb_R1Table = 0.0;
  for (i = 0; i < 3; i++) {
    rtb_R1Table += (((-P_kk1[(3 * i) + 1]) + (P_kk1[3 * i] * H[0])) + (-P_kk1[(3
      * i) + 2])) * H[i];
  }

  rtb_R1Table += IAEKF_DW.R_f2;
  v = IAEKF_U.Voltage - (((((((((4.208 * rt_powd_snf(IAEKF_DW.UnitDelay_DSTATE,
    5.0)) - (9.79 * v)) + (8.566 * e_out)) - (H_tmp * 3.349)) + (0.6719 *
    IAEKF_DW.UnitDelay_DSTATE)) + 1.354) - IAEKF_DW.X_k1_p[1]) -
    IAEKF_DW.X_k1_p[2]) - (rtb_R0Table * IAEKF_B.Gain));
  for (i = 0; i < 3; i++) {
    d = (((P_kk1[i] * H[0]) + (-P_kk1[i + 3])) + (-P_kk1[i + 6])) / rtb_R1Table;
    IAEKF_DW.X_k1_p[i] = (d * v) + X_kk1[i];
    K[i] = d;
  }

  for (i = 0; i < 9; i++) {
    b_I[i] = 0;
  }

  b_I[0] = 1;
  b_I[4] = 1;
  b_I[8] = 1;
  for (i = 0; i < 3; i++) {
    rtb_R1Table = H[i];
    A[3 * i] = ((real_T)b_I[3 * i]) - (K[0] * rtb_R1Table);
    b_I_tmp = (3 * i) + 1;
    A[b_I_tmp] = ((real_T)b_I[b_I_tmp]) - (K[1] * rtb_R1Table);
    b_I_tmp = (3 * i) + 2;
    A[b_I_tmp] = ((real_T)b_I[b_I_tmp]) - (K[2] * rtb_R1Table);
  }

  /*  ����Ӧ�������˲� */
  d = 0.0080000000000000071 / (1.0 - rt_powd_snf(0.992, IAEKF_DW.k_l));
  rtb_R1Table = 0.0;
  A_tmp = 0.0;
  for (i = 0; i < 3; i++) {
    rtb_R1Table += H[i] * X_kk1[i];
    H_0[i] = 0.0;
    for (b_I_tmp = 0; b_I_tmp < 3; b_I_tmp++) {
      A_tmp_0 = (3 * b_I_tmp) + i;
      IAEKF_DW.P_k1_d[A_tmp_0] = 0.0;
      IAEKF_DW.P_k1_d[A_tmp_0] += P_kk1[3 * b_I_tmp] * A[i];
      IAEKF_DW.P_k1_d[A_tmp_0] += P_kk1[(3 * b_I_tmp) + 1] * A[i + 3];
      IAEKF_DW.P_k1_d[A_tmp_0] += P_kk1[(3 * b_I_tmp) + 2] * A[i + 6];
      H_0[i] += P_kk1[(3 * i) + b_I_tmp] * H[b_I_tmp];
    }

    A_tmp += H_0[i] * H[i];
    IAEKF_DW.q_a[i] = ((1.0 - d) * IAEKF_DW.q_a[i]) + ((IAEKF_DW.X_k1_p[i] -
      X_kk1_tmp[i]) * d);
  }

  IAEKF_DW.r_j = ((1.0 - d) * IAEKF_DW.r_j) + ((IAEKF_U.Voltage - rtb_R1Table) *
    d);
  v -= IAEKF_DW.r_j;
  v *= v;
  IAEKF_DW.R_f2 = ((v - A_tmp) * d) + ((1.0 - d) * IAEKF_DW.R_f2);
  for (i = 0; i < 3; i++) {
    P_kk1[3 * i] = K[0] * K[i];
    P_kk1[(3 * i) + 1] = K[1] * K[i];
    P_kk1[(3 * i) + 2] = K[2] * K[i];
  }

  for (i = 0; i < 9; i++) {
    IAEKF_DW.Q_m[i] = ((((v * P_kk1[i]) + IAEKF_DW.P_k1_d[i]) - P_kk1_tmp[i]) *
                       d) + ((1.0 - d) * IAEKF_DW.Q_m[i]);
  }

  IAEKF_DW.UnitDelay_DSTATE = IAEKF_DW.X_k1_p[0];
  IAEKF_DW.k_l++;

  /* End of MATLAB Function: '<S2>/MATLAB Function' */

  /* Outport: '<Root>/SOC_SAEKF' incorporates:
   *  UnitDelay: '<S2>/Unit Delay'
   */
  IAEKF_Y.SOC_SAEKF = IAEKF_DW.UnitDelay_DSTATE;

  /* Outputs for Enabled SubSystem: '<S19>/Correct1' incorporates:
   *  EnablePort: '<S22>/Enable'
   */
  /* MATLAB Function: '<S22>/Correct' incorporates:
   *  Constant: '<S19>/R1'
   *  DataStoreRead: '<S22>/Data Store ReadX'
   *  DataStoreWrite: '<S22>/Data Store WriteP'
   *  Inport: '<Root>/Voltage'
   */
  /*  ekfCorrect Correction step for EKF */
  /*  */
  /*    Copyright 2016-2021 The MathWorks, Inc. */
  /*  If measurement noise is time-varying then compute square-root */
  /*  factorization. */
  /*  Construct the function handle for measurement fcn */
  /*  Construct the function handle for measurement Jacobian fcn */
  /*  Handle (optional) extra input arguments of the measurement & jacobian fcns */
  /*  Construct the corrector, perform the update */
  /*  Check if dimensions and type of Measurement and Jacobian are correct */
  /*  Additive noise */
  /*  MeasurementFcn */
  (void)batteryMeasurementFcn(IAEKF_DW.x);
  EKFCorrectorAdditive_getMeasure(0.31622776601683794, IAEKF_DW.x, IAEKF_DW.P,
    &A_tmp, K, &v, H, &d);
  A_tmp = IAEKF_U.Voltage - A_tmp;
  X_kk1_tmp[0] = K[0];
  X_kk1_tmp[1] = K[1];
  X_kk1_tmp[2] = K[2];
  trisolve_MxVysJHk(v, X_kk1_tmp);
  K[0] = X_kk1_tmp[0];
  K[1] = X_kk1_tmp[1];
  K[2] = X_kk1_tmp[2];
  trisolve_MxVysJHk(v, K);
  v = -K[0];
  e_out = -K[1];
  H_tmp = -K[2];
  for (i = 0; i < 3; i++) {
    rtb_R1Table = H[i];
    A[3 * i] = v * rtb_R1Table;
    A[(3 * i) + 1] = e_out * rtb_R1Table;
    A[(3 * i) + 2] = H_tmp * rtb_R1Table;
  }

  H[0] = K[0] * d;
  A[0]++;
  H[1] = K[1] * d;
  A[4]++;
  H[2] = K[2] * d;
  A[8]++;
  qrFactor_3S4uWW9E(A, IAEKF_DW.P, H);

  /* DataStoreWrite: '<S22>/Data Store WriteX' incorporates:
   *  DataStoreRead: '<S22>/Data Store ReadX'
   *  MATLAB Function: '<S22>/Correct'
   */
  IAEKF_DW.x[0] += K[0] * A_tmp;
  IAEKF_DW.x[1] += K[1] * A_tmp;
  IAEKF_DW.x[2] += K[2] * A_tmp;

  /* End of Outputs for SubSystem: '<S19>/Correct1' */

  /* Outport: '<Root>/SOC_EKF' incorporates:
   *  DataStoreRead: '<S23>/Data Store Read'
   */
  /*  Get back Covariance from Square-root Covariance */
  IAEKF_Y.SOC_EKF = IAEKF_DW.x[0];

  /* Lookup_n-D: '<S30>/R0 Table' incorporates:
   *  UnitDelay: '<S8>/Unit Delay'
   */
  rtb_R0Table_mt = look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_i,
    rtCP_R0Table_bp01Data_o, rtCP_R0Table_tableData_k, 10U);

  /* Lookup_n-D: '<S30>/R1 Table' incorporates:
   *  UnitDelay: '<S8>/Unit Delay'
   */
  rtb_R0Table = look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_i,
    rtCP_R1Table_bp01Data_n, rtCP_R1Table_tableData_a, 10U);

  /* Lookup_n-D: '<S30>/R2 Table' incorporates:
   *  UnitDelay: '<S8>/Unit Delay'
   */
  rtb_R2Table = look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_i,
    rtCP_R2Table_bp01Data_c, rtCP_R2Table_tableData_a, 10U);

  /* MATLAB Function: '<S8>/MATLAB Function' incorporates:
   *  Constant: '<S8>/Constant'
   *  Constant: '<S8>/Constant1'
   *  Inport: '<Root>/Voltage'
   *  Lookup_n-D: '<S30>/t1 Table'
   *  Lookup_n-D: '<S30>/t2 Table'
   *  UnitDelay: '<S8>/Unit Delay'
   */
  /*  ȷ��״̬����͹۲���� */
  d = exp(-0.5 / look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_i,
           rtCP_t1Table_bp01Data_m, rtCP_t1Table_tableData_j, 10U));
  A_tmp = exp(-0.5 / look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_i,
    rtCP_t2Table_bp01Data_m, rtCP_t2Table_tableData_a, 10U));
  A[0] = 1.0;
  A[3] = 0.0;
  A[6] = 0.0;
  A[1] = 0.0;
  A[4] = d;
  A[7] = 0.0;
  A[2] = 0.0;
  A[5] = 0.0;
  A[8] = A_tmp;
  IAEKF_DW.UnitDelay_DSTATE_i = IAEKF_DW.X_k1[0];
  v = rt_powd_snf(IAEKF_DW.UnitDelay_DSTATE_i, 4.0);
  e_out = rt_powd_snf(IAEKF_DW.UnitDelay_DSTATE_i, 3.0);
  H_tmp = IAEKF_DW.UnitDelay_DSTATE_i * IAEKF_DW.UnitDelay_DSTATE_i;
  H[0] = ((((18.240000000000002 * v) - (31.48 * e_out)) + (H_tmp * 18.729)) -
          (4.38 * IAEKF_DW.UnitDelay_DSTATE_i)) + 0.5074;
  H[1] = -1.0;
  H[2] = -1.0;

  /*  ȷ��״̬�۲���󣬼�������� */
  /*  �������˲� */
  for (i = 0; i < 3; i++) {
    for (b_I_tmp = 0; b_I_tmp < 3; b_I_tmp++) {
      A_tmp_0 = (3 * b_I_tmp) + i;
      A_0[A_tmp_0] = 0.0;
      A_0[A_tmp_0] += IAEKF_DW.P_k1[3 * b_I_tmp] * A[i];
      A_0[A_tmp_0] += IAEKF_DW.P_k1[(3 * b_I_tmp) + 1] * A[i + 3];
      A_0[A_tmp_0] += IAEKF_DW.P_k1[(3 * b_I_tmp) + 2] * A[i + 6];
    }

    for (b_I_tmp = 0; b_I_tmp < 3; b_I_tmp++) {
      A_tmp_0 = (3 * b_I_tmp) + i;
      P_kk1[A_tmp_0] = (((A_0[i + 3] * A[b_I_tmp + 3]) + (A_0[i] * A[b_I_tmp]))
                        + (A_0[i + 6] * A[b_I_tmp + 6])) + IAEKF_DW.Q[A_tmp_0];
    }
  }

  rtb_R1Table = 0.0;
  for (i = 0; i < 3; i++) {
    rtb_R1Table += (((-P_kk1[(3 * i) + 1]) + (P_kk1[3 * i] * H[0])) + (-P_kk1[(3
      * i) + 2])) * H[i];
  }

  rtb_R1Table += IAEKF_DW.R;
  v = IAEKF_U.Voltage - (((((((((3.648 * rt_powd_snf(IAEKF_DW.UnitDelay_DSTATE_i,
    5.0)) - (7.87 * v)) + (6.243 * e_out)) - (H_tmp * 2.19)) + (0.5074 *
    IAEKF_DW.UnitDelay_DSTATE_i)) + 1.333) - IAEKF_DW.X_k1[1]) - IAEKF_DW.X_k1[2])
    - (rtb_R0Table_mt * IAEKF_B.Gain));
  e_out = fabs(v / IAEKF_U.Voltage);
  if (e_out > 0.15) {
    e_out = 1.5;
  } else if (e_out < 0.05) {
    e_out = 0.1;
  } else {
    e_out = 1.0;
  }

  for (i = 0; i < 3; i++) {
    K[i] = (((P_kk1[i] * H[0]) + (-P_kk1[i + 3])) + (-P_kk1[i + 6])) /
      rtb_R1Table;
    X_kk1_tmp[i] = ((A[i + 3] * IAEKF_DW.X_k1[1]) + (A[i] * IAEKF_DW.X_k1[0])) +
      (A[i + 6] * IAEKF_DW.X_k1[2]);
  }

  IAEKF_DW.X_k1[0] = ((-9.92063492063492E-5 * IAEKF_B.Gain) + X_kk1_tmp[0]) +
    ((e_out * K[0]) * v);
  IAEKF_DW.X_k1[1] = ((((1.0 - d) * rtb_R0Table) * IAEKF_B.Gain) + X_kk1_tmp[1])
    + ((e_out * K[1]) * v);
  IAEKF_DW.X_k1[2] = ((((1.0 - A_tmp) * rtb_R2Table) * IAEKF_B.Gain) +
                      X_kk1_tmp[2]) + ((e_out * K[2]) * v);
  (void)memset(&A[0], 0, 9U * (sizeof(real_T)));
  A[0] = 1.0;
  A[4] = 1.0;
  A[8] = 1.0;
  for (i = 0; i < 3; i++) {
    rtb_R1Table = H[i];
    A_0[3 * i] = A[3 * i] - (K[0] * rtb_R1Table);
    A_tmp_0 = (3 * i) + 1;
    A_0[A_tmp_0] = A[A_tmp_0] - (K[1] * rtb_R1Table);
    A_tmp_0 = (3 * i) + 2;
    A_0[A_tmp_0] = A[A_tmp_0] - (K[2] * rtb_R1Table);
  }

  IAEKF_DW.UnitDelay_DSTATE_i = IAEKF_DW.X_k1[0];

  /* Outport: '<Root>/SOC_IEKF' incorporates:
   *  UnitDelay: '<S8>/Unit Delay'
   */
  IAEKF_Y.SOC_IEKF = IAEKF_DW.UnitDelay_DSTATE_i;

  /* Lookup_n-D: '<S18>/R0 Table' incorporates:
   *  UnitDelay: '<S6>/Unit Delay'
   */
  rtb_R0Table = look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_n,
    rtCP_R0Table_bp01Data_k, rtCP_R0Table_tableData_kd, 10U);

  /* Lookup_n-D: '<S18>/R1 Table' incorporates:
   *  UnitDelay: '<S6>/Unit Delay'
   */
  rtb_R1Table = look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_n,
    rtCP_R1Table_bp01Data_l, rtCP_R1Table_tableData_h, 10U);

  /* Lookup_n-D: '<S18>/R2 Table' incorporates:
   *  UnitDelay: '<S6>/Unit Delay'
   */
  rtb_R2Table = look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_n,
    rtCP_R2Table_bp01Data_h, rtCP_R2Table_tableData_i, 10U);

  /* MATLAB Function: '<S6>/MATLAB Function' incorporates:
   *  Lookup_n-D: '<S18>/t1 Table'
   *  Lookup_n-D: '<S18>/t2 Table'
   *  UnitDelay: '<S6>/Unit Delay'
   */
  /*  ȷ��״̬����͹۲���� */
  d = exp(-0.5 / look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_n,
           rtCP_t1Table_bp01Data_h, rtCP_t1Table_tableData_b, 10U));
  A_tmp = exp(-0.5 / look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_n,
    rtCP_t2Table_bp01Data_c, rtCP_t2Table_tableData_e, 10U));
  A[0] = 1.0;
  A[3] = 0.0;
  A[6] = 0.0;
  A[1] = 0.0;
  A[4] = d;
  A[7] = 0.0;
  A[2] = 0.0;
  A[5] = 0.0;
  A[8] = A_tmp;
  IAEKF_DW.UnitDelay_DSTATE_n = IAEKF_DW.X_k1_b[0];
  v = rt_powd_snf(IAEKF_DW.UnitDelay_DSTATE_n, 4.0);
  e_out = rt_powd_snf(IAEKF_DW.UnitDelay_DSTATE_n, 3.0);
  H_tmp = IAEKF_DW.UnitDelay_DSTATE_n * IAEKF_DW.UnitDelay_DSTATE_n;
  H[0] = ((((21.04 * v) - (39.16 * e_out)) + (H_tmp * 25.698)) - (6.698 *
           IAEKF_DW.UnitDelay_DSTATE_n)) + 0.6719;
  H[1] = -1.0;
  H[2] = -1.0;

  /*  ȷ��״̬�۲���󣬼�������� */
  /*  �������˲� */
  for (i = 0; i < 3; i++) {
    /* MATLAB Function: '<S6>/MATLAB Function' */
    X_kk1_tmp[i] = 0.0;
    for (b_I_tmp = 0; b_I_tmp < 3; b_I_tmp++) {
      /* MATLAB Function: '<S8>/MATLAB Function' */
      A_tmp_0 = (3 * i) + b_I_tmp;
      IAEKF_DW.P_k1[A_tmp_0] = 0.0;
      IAEKF_DW.P_k1[A_tmp_0] += P_kk1[3 * i] * A_0[b_I_tmp];
      IAEKF_DW.P_k1[A_tmp_0] += P_kk1[(3 * i) + 1] * A_0[b_I_tmp + 3];
      IAEKF_DW.P_k1[A_tmp_0] += P_kk1[(3 * i) + 2] * A_0[b_I_tmp + 6];

      /* MATLAB Function: '<S6>/MATLAB Function' */
      A_tmp_0 = (3 * b_I_tmp) + i;
      A_1[A_tmp_0] = 0.0;
      A_1[A_tmp_0] += IAEKF_DW.P_k1_h[3 * b_I_tmp] * A[i];
      A_1[A_tmp_0] += IAEKF_DW.P_k1_h[(3 * b_I_tmp) + 1] * A[i + 3];
      A_1[A_tmp_0] += IAEKF_DW.P_k1_h[(3 * b_I_tmp) + 2] * A[i + 6];
      X_kk1_tmp[i] += A[A_tmp_0] * IAEKF_DW.X_k1_b[b_I_tmp];
    }

    /* MATLAB Function: '<S6>/MATLAB Function' */
    for (b_I_tmp = 0; b_I_tmp < 3; b_I_tmp++) {
      A_tmp_0 = (3 * b_I_tmp) + i;
      P_kk1_tmp[A_tmp_0] = 0.0;
      P_kk1_tmp[A_tmp_0] += A_1[i] * A[b_I_tmp];
      P_kk1_tmp[A_tmp_0] += A_1[i + 3] * A[b_I_tmp + 3];
      P_kk1_tmp[A_tmp_0] += A_1[i + 6] * A[b_I_tmp + 6];
    }
  }

  /* MATLAB Function: '<S6>/MATLAB Function' incorporates:
   *  Constant: '<S6>/Constant'
   *  Inport: '<Root>/Voltage'
   *  UnitDelay: '<S6>/Unit Delay'
   */
  X_kk1[0] = (-9.92063492063492E-5 * IAEKF_B.Gain) + X_kk1_tmp[0];
  X_kk1[1] = (((1.0 - d) * rtb_R1Table) * IAEKF_B.Gain) + X_kk1_tmp[1];
  X_kk1[2] = (((1.0 - A_tmp) * rtb_R2Table) * IAEKF_B.Gain) + X_kk1_tmp[2];
  for (i = 0; i < 9; i++) {
    P_kk1[i] = P_kk1_tmp[i] + IAEKF_DW.Q_i[i];
  }

  rtb_R1Table = 0.0;
  for (i = 0; i < 3; i++) {
    rtb_R1Table += (((-P_kk1[(3 * i) + 1]) + (P_kk1[3 * i] * H[0])) + (-P_kk1[(3
      * i) + 2])) * H[i];
  }

  rtb_R1Table += IAEKF_DW.R_c;
  v = IAEKF_U.Voltage - (((((((((4.208 * rt_powd_snf(IAEKF_DW.UnitDelay_DSTATE_n,
    5.0)) - (9.79 * v)) + (8.566 * e_out)) - (H_tmp * 3.349)) + (0.6719 *
    IAEKF_DW.UnitDelay_DSTATE_n)) + 1.354) - IAEKF_DW.X_k1_b[1]) -
    IAEKF_DW.X_k1_b[2]) - (rtb_R0Table * IAEKF_B.Gain));
  for (i = 0; i < 3; i++) {
    d = (((P_kk1[i] * H[0]) + (-P_kk1[i + 3])) + (-P_kk1[i + 6])) / rtb_R1Table;
    IAEKF_DW.X_k1_b[i] = (d * v) + X_kk1[i];
    K[i] = d;
  }

  for (i = 0; i < 9; i++) {
    b_I[i] = 0;
  }

  b_I[0] = 1;
  b_I[4] = 1;
  b_I[8] = 1;
  for (i = 0; i < 3; i++) {
    rtb_R1Table = H[i];
    A[3 * i] = ((real_T)b_I[3 * i]) - (K[0] * rtb_R1Table);
    b_I_tmp = (3 * i) + 1;
    A[b_I_tmp] = ((real_T)b_I[b_I_tmp]) - (K[1] * rtb_R1Table);
    b_I_tmp = (3 * i) + 2;
    A[b_I_tmp] = ((real_T)b_I[b_I_tmp]) - (K[2] * rtb_R1Table);
  }

  /*  ����Ӧ�������˲� */
  d = 0.0080000000000000071 / (1.0 - rt_powd_snf(0.992, IAEKF_DW.k));
  rtb_R1Table = 0.0;
  A_tmp = 0.0;
  for (i = 0; i < 3; i++) {
    rtb_R1Table += H[i] * X_kk1[i];
    H_0[i] = 0.0;
    for (b_I_tmp = 0; b_I_tmp < 3; b_I_tmp++) {
      A_tmp_0 = (3 * b_I_tmp) + i;
      IAEKF_DW.P_k1_h[A_tmp_0] = 0.0;
      IAEKF_DW.P_k1_h[A_tmp_0] += P_kk1[3 * b_I_tmp] * A[i];
      IAEKF_DW.P_k1_h[A_tmp_0] += P_kk1[(3 * b_I_tmp) + 1] * A[i + 3];
      IAEKF_DW.P_k1_h[A_tmp_0] += P_kk1[(3 * b_I_tmp) + 2] * A[i + 6];
      H_0[i] += P_kk1[(3 * i) + b_I_tmp] * H[b_I_tmp];
    }

    A_tmp += H_0[i] * H[i];
    IAEKF_DW.q[i] = ((1.0 - d) * IAEKF_DW.q[i]) + ((IAEKF_DW.X_k1_b[i] -
      X_kk1_tmp[i]) * d);
  }

  IAEKF_DW.r = ((1.0 - d) * IAEKF_DW.r) + ((IAEKF_U.Voltage - rtb_R1Table) * d);
  v -= IAEKF_DW.r;
  v *= v;
  IAEKF_DW.R_c = ((v - A_tmp) * d) + ((1.0 - d) * IAEKF_DW.R_c);
  for (i = 0; i < 3; i++) {
    P_kk1[3 * i] = K[0] * K[i];
    P_kk1[(3 * i) + 1] = K[1] * K[i];
    P_kk1[(3 * i) + 2] = K[2] * K[i];
  }

  for (i = 0; i < 9; i++) {
    IAEKF_DW.Q_i[i] = ((((v * P_kk1[i]) + IAEKF_DW.P_k1_h[i]) - P_kk1_tmp[i]) *
                       d) + ((1.0 - d) * IAEKF_DW.Q_i[i]);
  }

  IAEKF_DW.UnitDelay_DSTATE_n = IAEKF_DW.X_k1_b[0];
  IAEKF_DW.k++;

  /* Outport: '<Root>/SOC_SAEKF_08' incorporates:
   *  UnitDelay: '<S6>/Unit Delay'
   */
  IAEKF_Y.SOC_SAEKF_08 = IAEKF_DW.UnitDelay_DSTATE_n;

  /* Lookup_n-D: '<S16>/R0 Table' incorporates:
   *  UnitDelay: '<S5>/Unit Delay'
   */
  rtb_R0Table = look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_l,
    rtCP_R0Table_bp01Data_e, rtCP_R0Table_tableData_d, 10U);

  /* Lookup_n-D: '<S16>/R1 Table' incorporates:
   *  UnitDelay: '<S5>/Unit Delay'
   */
  rtb_R1Table = look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_l,
    rtCP_R1Table_bp01Data_j, rtCP_R1Table_tableData_j, 10U);

  /* Lookup_n-D: '<S16>/R2 Table' incorporates:
   *  UnitDelay: '<S5>/Unit Delay'
   */
  rtb_R2Table = look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_l,
    rtCP_R2Table_bp01Data_a, rtCP_R2Table_tableData_iv, 10U);

  /* MATLAB Function: '<S5>/MATLAB Function' incorporates:
   *  Constant: '<S5>/Constant'
   *  Inport: '<Root>/Voltage'
   *  Lookup_n-D: '<S16>/t1 Table'
   *  Lookup_n-D: '<S16>/t2 Table'
   *  UnitDelay: '<S5>/Unit Delay'
   */
  /*  ȷ��״̬����͹۲���� */
  d = exp(-0.5 / look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_l,
           rtCP_t1Table_bp01Data_mt, rtCP_t1Table_tableData_m, 10U));
  A_tmp = exp(-0.5 / look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_l,
    rtCP_t2Table_bp01Data_e, rtCP_t2Table_tableData_h, 10U));
  A[0] = 1.0;
  A[3] = 0.0;
  A[6] = 0.0;
  A[1] = 0.0;
  A[4] = d;
  A[7] = 0.0;
  A[2] = 0.0;
  A[5] = 0.0;
  A[8] = A_tmp;
  IAEKF_DW.UnitDelay_DSTATE_l = IAEKF_DW.X_k1_a[0];
  v = rt_powd_snf(IAEKF_DW.UnitDelay_DSTATE_l, 4.0);
  e_out = rt_powd_snf(IAEKF_DW.UnitDelay_DSTATE_l, 3.0);
  H_tmp = IAEKF_DW.UnitDelay_DSTATE_l * IAEKF_DW.UnitDelay_DSTATE_l;
  H[0] = ((((21.04 * v) - (39.16 * e_out)) + (H_tmp * 25.698)) - (6.698 *
           IAEKF_DW.UnitDelay_DSTATE_l)) + 0.6719;
  H[1] = -1.0;
  H[2] = -1.0;

  /*  ȷ��״̬�۲���󣬼�������� */
  /*  �������˲� */
  for (i = 0; i < 3; i++) {
    X_kk1_tmp[i] = 0.0;
    for (b_I_tmp = 0; b_I_tmp < 3; b_I_tmp++) {
      A_tmp_0 = (3 * b_I_tmp) + i;
      A_0[A_tmp_0] = 0.0;
      A_0[A_tmp_0] += IAEKF_DW.P_k1_n[3 * b_I_tmp] * A[i];
      A_0[A_tmp_0] += IAEKF_DW.P_k1_n[(3 * b_I_tmp) + 1] * A[i + 3];
      A_0[A_tmp_0] += IAEKF_DW.P_k1_n[(3 * b_I_tmp) + 2] * A[i + 6];
      X_kk1_tmp[i] += A[A_tmp_0] * IAEKF_DW.X_k1_a[b_I_tmp];
    }

    for (b_I_tmp = 0; b_I_tmp < 3; b_I_tmp++) {
      A_tmp_0 = (3 * b_I_tmp) + i;
      P_kk1_tmp[A_tmp_0] = 0.0;
      P_kk1_tmp[A_tmp_0] += A_0[i] * A[b_I_tmp];
      P_kk1_tmp[A_tmp_0] += A_0[i + 3] * A[b_I_tmp + 3];
      P_kk1_tmp[A_tmp_0] += A_0[i + 6] * A[b_I_tmp + 6];
    }
  }

  X_kk1[0] = (-9.92063492063492E-5 * IAEKF_B.Gain) + X_kk1_tmp[0];
  X_kk1[1] = (((1.0 - d) * rtb_R1Table) * IAEKF_B.Gain) + X_kk1_tmp[1];
  X_kk1[2] = (((1.0 - A_tmp) * rtb_R2Table) * IAEKF_B.Gain) + X_kk1_tmp[2];
  for (i = 0; i < 9; i++) {
    P_kk1[i] = P_kk1_tmp[i] + IAEKF_DW.Q_k[i];
  }

  rtb_R1Table = 0.0;
  for (i = 0; i < 3; i++) {
    rtb_R1Table += (((-P_kk1[(3 * i) + 1]) + (P_kk1[3 * i] * H[0])) + (-P_kk1[(3
      * i) + 2])) * H[i];
  }

  rtb_R1Table += IAEKF_DW.R_n;
  v = IAEKF_U.Voltage - (((((((((4.208 * rt_powd_snf(IAEKF_DW.UnitDelay_DSTATE_l,
    5.0)) - (9.79 * v)) + (8.566 * e_out)) - (H_tmp * 3.349)) + (0.6719 *
    IAEKF_DW.UnitDelay_DSTATE_l)) + 1.354) - IAEKF_DW.X_k1_a[1]) -
    IAEKF_DW.X_k1_a[2]) - (rtb_R0Table * IAEKF_B.Gain));
  for (i = 0; i < 3; i++) {
    d = (((P_kk1[i] * H[0]) + (-P_kk1[i + 3])) + (-P_kk1[i + 6])) / rtb_R1Table;
    IAEKF_DW.X_k1_a[i] = (d * v) + X_kk1[i];
    K[i] = d;
  }

  for (i = 0; i < 9; i++) {
    b_I[i] = 0;
  }

  b_I[0] = 1;
  b_I[4] = 1;
  b_I[8] = 1;
  for (i = 0; i < 3; i++) {
    rtb_R1Table = H[i];
    A[3 * i] = ((real_T)b_I[3 * i]) - (K[0] * rtb_R1Table);
    b_I_tmp = (3 * i) + 1;
    A[b_I_tmp] = ((real_T)b_I[b_I_tmp]) - (K[1] * rtb_R1Table);
    b_I_tmp = (3 * i) + 2;
    A[b_I_tmp] = ((real_T)b_I[b_I_tmp]) - (K[2] * rtb_R1Table);
  }

  /*  ����Ӧ�������˲� */
  d = 0.0080000000000000071 / (1.0 - rt_powd_snf(0.992, IAEKF_DW.k_e));
  rtb_R1Table = 0.0;
  A_tmp = 0.0;
  for (i = 0; i < 3; i++) {
    rtb_R1Table += H[i] * X_kk1[i];
    H_0[i] = 0.0;
    for (b_I_tmp = 0; b_I_tmp < 3; b_I_tmp++) {
      A_tmp_0 = (3 * b_I_tmp) + i;
      IAEKF_DW.P_k1_n[A_tmp_0] = 0.0;
      IAEKF_DW.P_k1_n[A_tmp_0] += P_kk1[3 * b_I_tmp] * A[i];
      IAEKF_DW.P_k1_n[A_tmp_0] += P_kk1[(3 * b_I_tmp) + 1] * A[i + 3];
      IAEKF_DW.P_k1_n[A_tmp_0] += P_kk1[(3 * b_I_tmp) + 2] * A[i + 6];
      H_0[i] += P_kk1[(3 * i) + b_I_tmp] * H[b_I_tmp];
    }

    A_tmp += H_0[i] * H[i];
    IAEKF_DW.q_o[i] = ((1.0 - d) * IAEKF_DW.q_o[i]) + ((IAEKF_DW.X_k1_a[i] -
      X_kk1_tmp[i]) * d);
  }

  IAEKF_DW.r_n = ((1.0 - d) * IAEKF_DW.r_n) + ((IAEKF_U.Voltage - rtb_R1Table) *
    d);
  v -= IAEKF_DW.r_n;
  v *= v;
  IAEKF_DW.R_n = ((v - A_tmp) * d) + ((1.0 - d) * IAEKF_DW.R_n);
  for (i = 0; i < 3; i++) {
    P_kk1[3 * i] = K[0] * K[i];
    P_kk1[(3 * i) + 1] = K[1] * K[i];
    P_kk1[(3 * i) + 2] = K[2] * K[i];
  }

  for (i = 0; i < 9; i++) {
    IAEKF_DW.Q_k[i] = ((((v * P_kk1[i]) + IAEKF_DW.P_k1_n[i]) - P_kk1_tmp[i]) *
                       d) + ((1.0 - d) * IAEKF_DW.Q_k[i]);
  }

  IAEKF_DW.UnitDelay_DSTATE_l = IAEKF_DW.X_k1_a[0];
  IAEKF_DW.k_e++;

  /* End of MATLAB Function: '<S5>/MATLAB Function' */

  /* Outport: '<Root>/SOC_SAEKF_06' incorporates:
   *  UnitDelay: '<S5>/Unit Delay'
   */
  IAEKF_Y.SOC_SAEKF_06 = IAEKF_DW.UnitDelay_DSTATE_l;

  /* Lookup_n-D: '<S14>/R0 Table' incorporates:
   *  UnitDelay: '<S4>/Unit Delay'
   */
  rtb_R0Table = look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_c,
    rtCP_R0Table_bp01Data_f, rtCP_R0Table_tableData_j, 10U);

  /* Lookup_n-D: '<S14>/R1 Table' incorporates:
   *  UnitDelay: '<S4>/Unit Delay'
   */
  rtb_R1Table = look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_c,
    rtCP_R1Table_bp01Data_c, rtCP_R1Table_tableData_l, 10U);

  /* Lookup_n-D: '<S14>/R2 Table' incorporates:
   *  UnitDelay: '<S4>/Unit Delay'
   */
  rtb_R2Table = look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_c,
    rtCP_R2Table_bp01Data_p, rtCP_R2Table_tableData_e, 10U);

  /* MATLAB Function: '<S4>/MATLAB Function' incorporates:
   *  Constant: '<S4>/Constant'
   *  Inport: '<Root>/Voltage'
   *  Lookup_n-D: '<S14>/t1 Table'
   *  Lookup_n-D: '<S14>/t2 Table'
   *  UnitDelay: '<S4>/Unit Delay'
   */
  /*  ȷ��״̬����͹۲���� */
  d = exp(-0.5 / look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_c,
           rtCP_t1Table_bp01Data_mo, rtCP_t1Table_tableData_k, 10U));
  A_tmp = exp(-0.5 / look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_c,
    rtCP_t2Table_bp01Data_k, rtCP_t2Table_tableData_n, 10U));
  A[0] = 1.0;
  A[3] = 0.0;
  A[6] = 0.0;
  A[1] = 0.0;
  A[4] = d;
  A[7] = 0.0;
  A[2] = 0.0;
  A[5] = 0.0;
  A[8] = A_tmp;
  IAEKF_DW.UnitDelay_DSTATE_c = IAEKF_DW.X_k1_m[0];
  v = rt_powd_snf(IAEKF_DW.UnitDelay_DSTATE_c, 4.0);
  e_out = rt_powd_snf(IAEKF_DW.UnitDelay_DSTATE_c, 3.0);
  H_tmp = IAEKF_DW.UnitDelay_DSTATE_c * IAEKF_DW.UnitDelay_DSTATE_c;
  H[0] = ((((21.04 * v) - (39.16 * e_out)) + (H_tmp * 25.698)) - (6.698 *
           IAEKF_DW.UnitDelay_DSTATE_c)) + 0.6719;
  H[1] = -1.0;
  H[2] = -1.0;

  /*  ȷ��״̬�۲���󣬼�������� */
  /*  �������˲� */
  for (i = 0; i < 3; i++) {
    X_kk1_tmp[i] = 0.0;
    for (b_I_tmp = 0; b_I_tmp < 3; b_I_tmp++) {
      A_tmp_0 = (3 * b_I_tmp) + i;
      A_0[A_tmp_0] = 0.0;
      A_0[A_tmp_0] += IAEKF_DW.P_k1_e[3 * b_I_tmp] * A[i];
      A_0[A_tmp_0] += IAEKF_DW.P_k1_e[(3 * b_I_tmp) + 1] * A[i + 3];
      A_0[A_tmp_0] += IAEKF_DW.P_k1_e[(3 * b_I_tmp) + 2] * A[i + 6];
      X_kk1_tmp[i] += A[A_tmp_0] * IAEKF_DW.X_k1_m[b_I_tmp];
    }

    for (b_I_tmp = 0; b_I_tmp < 3; b_I_tmp++) {
      A_tmp_0 = (3 * b_I_tmp) + i;
      P_kk1_tmp[A_tmp_0] = 0.0;
      P_kk1_tmp[A_tmp_0] += A_0[i] * A[b_I_tmp];
      P_kk1_tmp[A_tmp_0] += A_0[i + 3] * A[b_I_tmp + 3];
      P_kk1_tmp[A_tmp_0] += A_0[i + 6] * A[b_I_tmp + 6];
    }
  }

  X_kk1[0] = (-9.92063492063492E-5 * IAEKF_B.Gain) + X_kk1_tmp[0];
  X_kk1[1] = (((1.0 - d) * rtb_R1Table) * IAEKF_B.Gain) + X_kk1_tmp[1];
  X_kk1[2] = (((1.0 - A_tmp) * rtb_R2Table) * IAEKF_B.Gain) + X_kk1_tmp[2];
  for (i = 0; i < 9; i++) {
    P_kk1[i] = P_kk1_tmp[i] + IAEKF_DW.Q_a[i];
  }

  rtb_R1Table = 0.0;
  for (i = 0; i < 3; i++) {
    rtb_R1Table += (((-P_kk1[(3 * i) + 1]) + (P_kk1[3 * i] * H[0])) + (-P_kk1[(3
      * i) + 2])) * H[i];
  }

  rtb_R1Table += IAEKF_DW.R_m;
  v = IAEKF_U.Voltage - (((((((((4.208 * rt_powd_snf(IAEKF_DW.UnitDelay_DSTATE_c,
    5.0)) - (9.79 * v)) + (8.566 * e_out)) - (H_tmp * 3.349)) + (0.6719 *
    IAEKF_DW.UnitDelay_DSTATE_c)) + 1.354) - IAEKF_DW.X_k1_m[1]) -
    IAEKF_DW.X_k1_m[2]) - (rtb_R0Table * IAEKF_B.Gain));
  for (i = 0; i < 3; i++) {
    d = (((P_kk1[i] * H[0]) + (-P_kk1[i + 3])) + (-P_kk1[i + 6])) / rtb_R1Table;
    IAEKF_DW.X_k1_m[i] = (d * v) + X_kk1[i];
    K[i] = d;
  }

  for (i = 0; i < 9; i++) {
    b_I[i] = 0;
  }

  b_I[0] = 1;
  b_I[4] = 1;
  b_I[8] = 1;
  for (i = 0; i < 3; i++) {
    rtb_R1Table = H[i];
    A[3 * i] = ((real_T)b_I[3 * i]) - (K[0] * rtb_R1Table);
    b_I_tmp = (3 * i) + 1;
    A[b_I_tmp] = ((real_T)b_I[b_I_tmp]) - (K[1] * rtb_R1Table);
    b_I_tmp = (3 * i) + 2;
    A[b_I_tmp] = ((real_T)b_I[b_I_tmp]) - (K[2] * rtb_R1Table);
  }

  /*  ����Ӧ�������˲� */
  d = 0.0080000000000000071 / (1.0 - rt_powd_snf(0.992, IAEKF_DW.k_d));
  rtb_R1Table = 0.0;
  A_tmp = 0.0;
  for (i = 0; i < 3; i++) {
    rtb_R1Table += H[i] * X_kk1[i];
    H_0[i] = 0.0;
    for (b_I_tmp = 0; b_I_tmp < 3; b_I_tmp++) {
      A_tmp_0 = (3 * b_I_tmp) + i;
      IAEKF_DW.P_k1_e[A_tmp_0] = 0.0;
      IAEKF_DW.P_k1_e[A_tmp_0] += P_kk1[3 * b_I_tmp] * A[i];
      IAEKF_DW.P_k1_e[A_tmp_0] += P_kk1[(3 * b_I_tmp) + 1] * A[i + 3];
      IAEKF_DW.P_k1_e[A_tmp_0] += P_kk1[(3 * b_I_tmp) + 2] * A[i + 6];
      H_0[i] += P_kk1[(3 * i) + b_I_tmp] * H[b_I_tmp];
    }

    A_tmp += H_0[i] * H[i];
    IAEKF_DW.q_k[i] = ((1.0 - d) * IAEKF_DW.q_k[i]) + ((IAEKF_DW.X_k1_m[i] -
      X_kk1_tmp[i]) * d);
  }

  IAEKF_DW.r_g = ((1.0 - d) * IAEKF_DW.r_g) + ((IAEKF_U.Voltage - rtb_R1Table) *
    d);
  v -= IAEKF_DW.r_g;
  v *= v;
  IAEKF_DW.R_m = ((v - A_tmp) * d) + ((1.0 - d) * IAEKF_DW.R_m);
  for (i = 0; i < 3; i++) {
    P_kk1[3 * i] = K[0] * K[i];
    P_kk1[(3 * i) + 1] = K[1] * K[i];
    P_kk1[(3 * i) + 2] = K[2] * K[i];
  }

  for (i = 0; i < 9; i++) {
    IAEKF_DW.Q_a[i] = ((((v * P_kk1[i]) + IAEKF_DW.P_k1_e[i]) - P_kk1_tmp[i]) *
                       d) + ((1.0 - d) * IAEKF_DW.Q_a[i]);
  }

  IAEKF_DW.UnitDelay_DSTATE_c = IAEKF_DW.X_k1_m[0];
  IAEKF_DW.k_d++;

  /* End of MATLAB Function: '<S4>/MATLAB Function' */

  /* Outport: '<Root>/SOC_SAEKF_04' incorporates:
   *  UnitDelay: '<S4>/Unit Delay'
   */
  IAEKF_Y.SOC_SAEKF_04 = IAEKF_DW.UnitDelay_DSTATE_c;

  /* Lookup_n-D: '<S12>/R0 Table' incorporates:
   *  UnitDelay: '<S3>/Unit Delay'
   */
  rtb_R0Table = look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_g,
    rtCP_R0Table_bp01Data_m, rtCP_R0Table_tableData_c, 10U);

  /* Lookup_n-D: '<S12>/R1 Table' incorporates:
   *  UnitDelay: '<S3>/Unit Delay'
   */
  rtb_R1Table = look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_g,
    rtCP_R1Table_bp01Data_d, rtCP_R1Table_tableData_hy, 10U);

  /* Lookup_n-D: '<S12>/R2 Table' incorporates:
   *  UnitDelay: '<S3>/Unit Delay'
   */
  rtb_R2Table = look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_g,
    rtCP_R2Table_bp01Data_hh, rtCP_R2Table_tableData_b, 10U);

  /* MATLAB Function: '<S3>/MATLAB Function' incorporates:
   *  Constant: '<S3>/Constant'
   *  Inport: '<Root>/Voltage'
   *  Lookup_n-D: '<S12>/t1 Table'
   *  Lookup_n-D: '<S12>/t2 Table'
   *  UnitDelay: '<S3>/Unit Delay'
   */
  /*  ȷ��״̬����͹۲���� */
  d = exp(-0.5 / look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_g,
           rtCP_t1Table_bp01Data_g, rtCP_t1Table_tableData_d, 10U));
  A_tmp = exp(-0.5 / look1_binlxpw(IAEKF_DW.UnitDelay_DSTATE_g,
    rtCP_t2Table_bp01Data_h, rtCP_t2Table_tableData_ne, 10U));
  A[0] = 1.0;
  A[3] = 0.0;
  A[6] = 0.0;
  A[1] = 0.0;
  A[4] = d;
  A[7] = 0.0;
  A[2] = 0.0;
  A[5] = 0.0;
  A[8] = A_tmp;
  IAEKF_DW.UnitDelay_DSTATE_g = IAEKF_DW.X_k1_l[0];
  v = rt_powd_snf(IAEKF_DW.UnitDelay_DSTATE_g, 4.0);
  e_out = rt_powd_snf(IAEKF_DW.UnitDelay_DSTATE_g, 3.0);
  H_tmp = IAEKF_DW.UnitDelay_DSTATE_g * IAEKF_DW.UnitDelay_DSTATE_g;
  H[0] = ((((21.04 * v) - (39.16 * e_out)) + (H_tmp * 25.698)) - (6.698 *
           IAEKF_DW.UnitDelay_DSTATE_g)) + 0.6719;
  H[1] = -1.0;
  H[2] = -1.0;

  /*  ȷ��״̬�۲���󣬼�������� */
  /*  �������˲� */
  for (i = 0; i < 3; i++) {
    X_kk1_tmp[i] = 0.0;
    for (b_I_tmp = 0; b_I_tmp < 3; b_I_tmp++) {
      A_tmp_0 = (3 * b_I_tmp) + i;
      A_0[A_tmp_0] = 0.0;
      A_0[A_tmp_0] += IAEKF_DW.P_k1_eq[3 * b_I_tmp] * A[i];
      A_0[A_tmp_0] += IAEKF_DW.P_k1_eq[(3 * b_I_tmp) + 1] * A[i + 3];
      A_0[A_tmp_0] += IAEKF_DW.P_k1_eq[(3 * b_I_tmp) + 2] * A[i + 6];
      X_kk1_tmp[i] += A[A_tmp_0] * IAEKF_DW.X_k1_l[b_I_tmp];
    }

    for (b_I_tmp = 0; b_I_tmp < 3; b_I_tmp++) {
      A_tmp_0 = (3 * b_I_tmp) + i;
      P_kk1_tmp[A_tmp_0] = 0.0;
      P_kk1_tmp[A_tmp_0] += A_0[i] * A[b_I_tmp];
      P_kk1_tmp[A_tmp_0] += A_0[i + 3] * A[b_I_tmp + 3];
      P_kk1_tmp[A_tmp_0] += A_0[i + 6] * A[b_I_tmp + 6];
    }
  }

  X_kk1[0] = (-9.92063492063492E-5 * IAEKF_B.Gain) + X_kk1_tmp[0];
  X_kk1[1] = (((1.0 - d) * rtb_R1Table) * IAEKF_B.Gain) + X_kk1_tmp[1];
  X_kk1[2] = (((1.0 - A_tmp) * rtb_R2Table) * IAEKF_B.Gain) + X_kk1_tmp[2];
  for (i = 0; i < 9; i++) {
    P_kk1[i] = P_kk1_tmp[i] + IAEKF_DW.Q_g[i];
  }

  rtb_R1Table = 0.0;
  for (i = 0; i < 3; i++) {
    rtb_R1Table += (((-P_kk1[(3 * i) + 1]) + (P_kk1[3 * i] * H[0])) + (-P_kk1[(3
      * i) + 2])) * H[i];
  }

  rtb_R1Table += IAEKF_DW.R_f;
  v = IAEKF_U.Voltage - (((((((((4.208 * rt_powd_snf(IAEKF_DW.UnitDelay_DSTATE_g,
    5.0)) - (9.79 * v)) + (8.566 * e_out)) - (H_tmp * 3.349)) + (0.6719 *
    IAEKF_DW.UnitDelay_DSTATE_g)) + 1.354) - IAEKF_DW.X_k1_l[1]) -
    IAEKF_DW.X_k1_l[2]) - (rtb_R0Table * IAEKF_B.Gain));
  for (i = 0; i < 3; i++) {
    d = (((P_kk1[i] * H[0]) + (-P_kk1[i + 3])) + (-P_kk1[i + 6])) / rtb_R1Table;
    IAEKF_DW.X_k1_l[i] = (d * v) + X_kk1[i];
    K[i] = d;
  }

  for (i = 0; i < 9; i++) {
    b_I[i] = 0;
  }

  b_I[0] = 1;
  b_I[4] = 1;
  b_I[8] = 1;
  for (i = 0; i < 3; i++) {
    rtb_R1Table = H[i];
    A[3 * i] = ((real_T)b_I[3 * i]) - (K[0] * rtb_R1Table);
    b_I_tmp = (3 * i) + 1;
    A[b_I_tmp] = ((real_T)b_I[b_I_tmp]) - (K[1] * rtb_R1Table);
    b_I_tmp = (3 * i) + 2;
    A[b_I_tmp] = ((real_T)b_I[b_I_tmp]) - (K[2] * rtb_R1Table);
  }

  /*  ����Ӧ�������˲� */
  d = 0.0080000000000000071 / (1.0 - rt_powd_snf(0.992, IAEKF_DW.k_o));
  rtb_R1Table = 0.0;
  A_tmp = 0.0;
  for (i = 0; i < 3; i++) {
    rtb_R1Table += H[i] * X_kk1[i];
    H_0[i] = 0.0;
    for (b_I_tmp = 0; b_I_tmp < 3; b_I_tmp++) {
      A_tmp_0 = (3 * b_I_tmp) + i;
      IAEKF_DW.P_k1_eq[A_tmp_0] = 0.0;
      IAEKF_DW.P_k1_eq[A_tmp_0] += P_kk1[3 * b_I_tmp] * A[i];
      IAEKF_DW.P_k1_eq[A_tmp_0] += P_kk1[(3 * b_I_tmp) + 1] * A[i + 3];
      IAEKF_DW.P_k1_eq[A_tmp_0] += P_kk1[(3 * b_I_tmp) + 2] * A[i + 6];
      H_0[i] += P_kk1[(3 * i) + b_I_tmp] * H[b_I_tmp];
    }

    A_tmp += H_0[i] * H[i];
    IAEKF_DW.q_n[i] = ((1.0 - d) * IAEKF_DW.q_n[i]) + ((IAEKF_DW.X_k1_l[i] -
      X_kk1_tmp[i]) * d);
  }

  IAEKF_DW.r_p = ((1.0 - d) * IAEKF_DW.r_p) + ((IAEKF_U.Voltage - rtb_R1Table) *
    d);
  v -= IAEKF_DW.r_p;
  v *= v;
  IAEKF_DW.R_f = ((v - A_tmp) * d) + ((1.0 - d) * IAEKF_DW.R_f);
  for (i = 0; i < 3; i++) {
    P_kk1[3 * i] = K[0] * K[i];
    P_kk1[(3 * i) + 1] = K[1] * K[i];
    P_kk1[(3 * i) + 2] = K[2] * K[i];
  }

  for (i = 0; i < 9; i++) {
    IAEKF_DW.Q_g[i] = ((((v * P_kk1[i]) + IAEKF_DW.P_k1_eq[i]) - P_kk1_tmp[i]) *
                       d) + ((1.0 - d) * IAEKF_DW.Q_g[i]);
  }

  IAEKF_DW.UnitDelay_DSTATE_g = IAEKF_DW.X_k1_l[0];
  IAEKF_DW.k_o++;

  /* End of MATLAB Function: '<S3>/MATLAB Function' */

  /* Outport: '<Root>/SOC_SAEKF_02' incorporates:
   *  UnitDelay: '<S3>/Unit Delay'
   */
  IAEKF_Y.SOC_SAEKF_02 = IAEKF_DW.UnitDelay_DSTATE_g;

  /* Outputs for Atomic SubSystem: '<S19>/Predict' */
  /* MATLAB Function: '<S24>/Predict' incorporates:
   *  DataStoreRead: '<S24>/Data Store ReadX'
   */
  /*  ekfCorrect Prediction step for EKF */
  /*  */
  /*    Copyright 2016-2021 The MathWorks, Inc. */
  /*  If process noise is time-varying then compute square-root */
  /*  factorization. */
  /*  Construct fcn handles */
  /*  Check if dimensions and type of State and Jacobian are correct */
  /*  Additive noise */
  /*  StateTransitionFcn */
  batteryStateFcn(IAEKF_DW.x, K);
  batteryStateFcn(IAEKF_DW.x, K);
  for (i = 0; i < 3; i++) {
    X_kk1_tmp[0] = IAEKF_DW.x[0];
    X_kk1_tmp[1] = IAEKF_DW.x[1];
    X_kk1_tmp[2] = IAEKF_DW.x[2];
    d = fmax(1.4901161193847656E-8, 1.4901161193847656E-8 * fabs(IAEKF_DW.x[i]));
    X_kk1_tmp[i] = IAEKF_DW.x[i] + d;
    batteryStateFcn(X_kk1_tmp, H);
    A[3 * i] = (H[0] - K[0]) / d;
    A[(3 * i) + 1] = (H[1] - K[1]) / d;
    A[(3 * i) + 2] = (H[2] - K[2]) / d;
  }

  for (i = 0; i < 3; i++) {
    H[i] = IAEKF_DW.x[i];
  }

  /* DataStoreWrite: '<S24>/Data Store WriteX' incorporates:
   *  MATLAB Function: '<S24>/Predict'
   */
  batteryStateFcn(H, IAEKF_DW.x);

  /* MATLAB Function: '<S24>/Predict' incorporates:
   *  Constant: '<S19>/Q'
   *  DataStoreWrite: '<S24>/Data Store WriteP'
   */
  qrFactor_yMceNYiC(A, IAEKF_DW.P, rtCP_Q_Value);

  /* End of Outputs for SubSystem: '<S19>/Predict' */
}

/* Model initialize function */
void IAEKF_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  {
    int32_T i;
    static const real_T tmp_0[9] = { 0.001, 0.0, 0.0, 0.0, 0.001, 0.0, 0.0, 0.0,
      0.001 };

    static const real_T tmp_1[9] = { 0.1, 0.0, 0.0, 0.0, 0.1, 0.0, 0.0, 0.0, 0.1
    };

    /* Start for DataStoreMemory: '<S19>/DataStoreMemory - P' */
    (void)memcpy(&IAEKF_DW.P[0], &rtCP_DataStoreMemoryP_InitialVa[0], 9U *
                 (sizeof(real_T)));

    /* Start for DataStoreMemory: '<S19>/DataStoreMemory - x' */
    IAEKF_DW.x[0] = 1.0;
    IAEKF_DW.x[1] = 0.0;
    IAEKF_DW.x[2] = 0.0;

    /* InitializeConditions for UnitDelay: '<S2>/Unit Delay' */
    IAEKF_DW.UnitDelay_DSTATE = 1.0;

    /* InitializeConditions for UnitDelay: '<S8>/Unit Delay' */
    IAEKF_DW.UnitDelay_DSTATE_i = 1.0;

    /* InitializeConditions for UnitDelay: '<S6>/Unit Delay' */
    IAEKF_DW.UnitDelay_DSTATE_n = 1.0;

    /* InitializeConditions for UnitDelay: '<S5>/Unit Delay' */
    IAEKF_DW.UnitDelay_DSTATE_l = 1.0;

    /* InitializeConditions for UnitDelay: '<S4>/Unit Delay' */
    IAEKF_DW.UnitDelay_DSTATE_c = 1.0;

    /* InitializeConditions for UnitDelay: '<S3>/Unit Delay' */
    IAEKF_DW.UnitDelay_DSTATE_g = 1.0;

    /* SystemInitialize for MATLAB Function: '<S2>/MATLAB Function' */
    IAEKF_DW.X_k1_p[0] = 1.0;
    IAEKF_DW.X_k1_p[1] = 0.0;
    IAEKF_DW.X_k1_p[2] = 0.0;

    /*  P ָ���ǵ�ǰ״̬��Э������� */
    /* ֵ��ͬЧ����ͬ����Ծ�ȷ�������ٶȴ���Ӱ�� */
    IAEKF_DW.R_f2 = 0.1;

    /* ֵ��ͬЧ����ͬ����Ծ�ȷ�������ٶȴ���Ӱ�� */
    /*  the mean of error  3*1ά */
    IAEKF_DW.q_a[0] = 0.1;
    IAEKF_DW.q_a[1] = 0.1;
    IAEKF_DW.q_a[2] = 0.1;

    /*  the mean of error  3*1ά */
    IAEKF_DW.r_j = 0.1;

    /*  the mean of error  3*1ά */
    IAEKF_DW.k_l = 1.0;

    /* SystemInitialize for MATLAB Function: '<S8>/MATLAB Function' */
    IAEKF_DW.X_k1[0] = 1.0;
    IAEKF_DW.X_k1[1] = 0.0;
    IAEKF_DW.X_k1[2] = 0.0;

    /*  P ָ���ǵ�ǰ״̬��Э������� */
    /* ֵ��ͬЧ����ͬ����Ծ�ȷ�������ٶȴ���Ӱ�� */
    IAEKF_DW.R = 0.1;

    /* SystemInitialize for MATLAB Function: '<S6>/MATLAB Function' */
    /* ֵ��ͬЧ����ͬ����Ծ�ȷ�������ٶȴ���Ӱ�� */
    IAEKF_DW.X_k1_b[0] = 0.8;
    IAEKF_DW.X_k1_b[1] = 0.0;
    IAEKF_DW.X_k1_b[2] = 0.0;

    /*  P ָ���ǵ�ǰ״̬��Э������� */
    /* ֵ��ͬЧ����ͬ����Ծ�ȷ�������ٶȴ���Ӱ�� */
    IAEKF_DW.R_c = 0.1;

    /* ֵ��ͬЧ����ͬ����Ծ�ȷ�������ٶȴ���Ӱ�� */
    /*  the mean of error  3*1ά */
    IAEKF_DW.q[0] = 0.1;
    IAEKF_DW.q[1] = 0.1;
    IAEKF_DW.q[2] = 0.1;

    /*  the mean of error  3*1ά */
    IAEKF_DW.r = 0.1;

    /*  the mean of error  3*1ά */
    IAEKF_DW.k = 1.0;

    /* SystemInitialize for MATLAB Function: '<S5>/MATLAB Function' */
    IAEKF_DW.X_k1_a[0] = 0.6;
    IAEKF_DW.X_k1_a[1] = 0.0;
    IAEKF_DW.X_k1_a[2] = 0.0;

    /*  P ָ���ǵ�ǰ״̬��Э������� */
    /* ֵ��ͬЧ����ͬ����Ծ�ȷ�������ٶȴ���Ӱ�� */
    IAEKF_DW.R_n = 0.1;

    /* ֵ��ͬЧ����ͬ����Ծ�ȷ�������ٶȴ���Ӱ�� */
    /*  the mean of error  3*1ά */
    IAEKF_DW.q_o[0] = 0.1;
    IAEKF_DW.q_o[1] = 0.1;
    IAEKF_DW.q_o[2] = 0.1;

    /*  the mean of error  3*1ά */
    IAEKF_DW.r_n = 0.1;

    /*  the mean of error  3*1ά */
    IAEKF_DW.k_e = 1.0;

    /* SystemInitialize for MATLAB Function: '<S4>/MATLAB Function' */
    IAEKF_DW.X_k1_m[0] = 0.4;
    IAEKF_DW.X_k1_m[1] = 0.0;
    IAEKF_DW.X_k1_m[2] = 0.0;

    /*  P ָ���ǵ�ǰ״̬��Э������� */
    /* ֵ��ͬЧ����ͬ����Ծ�ȷ�������ٶȴ���Ӱ�� */
    IAEKF_DW.R_m = 0.1;

    /* ֵ��ͬЧ����ͬ����Ծ�ȷ�������ٶȴ���Ӱ�� */
    /*  the mean of error  3*1ά */
    IAEKF_DW.q_k[0] = 0.1;
    IAEKF_DW.q_k[1] = 0.1;
    IAEKF_DW.q_k[2] = 0.1;

    /*  the mean of error  3*1ά */
    IAEKF_DW.r_g = 0.1;

    /*  the mean of error  3*1ά */
    IAEKF_DW.k_d = 1.0;

    /* SystemInitialize for MATLAB Function: '<S3>/MATLAB Function' */
    IAEKF_DW.X_k1_l[0] = 0.2;
    IAEKF_DW.X_k1_l[1] = 0.0;
    IAEKF_DW.X_k1_l[2] = 0.0;

    /*  P ָ���ǵ�ǰ״̬��Э������� */
    for (i = 0; i < 9; i++) {
      real_T tmp;

      /* SystemInitialize for MATLAB Function: '<S2>/MATLAB Function' */
      tmp = tmp_0[i];
      IAEKF_DW.P_k1_d[i] = tmp;
      IAEKF_DW.Q_m[i] = IAEKF_DW.P_k1_d[i];

      /* SystemInitialize for MATLAB Function: '<S8>/MATLAB Function' */
      IAEKF_DW.P_k1[i] = tmp_1[i];
      IAEKF_DW.Q[i] = tmp;

      /* SystemInitialize for MATLAB Function: '<S6>/MATLAB Function' */
      IAEKF_DW.P_k1_h[i] = tmp;
      IAEKF_DW.Q_i[i] = IAEKF_DW.P_k1_h[i];

      /* SystemInitialize for MATLAB Function: '<S5>/MATLAB Function' */
      IAEKF_DW.P_k1_n[i] = tmp;
      IAEKF_DW.Q_k[i] = IAEKF_DW.P_k1_n[i];

      /* SystemInitialize for MATLAB Function: '<S4>/MATLAB Function' */
      IAEKF_DW.P_k1_e[i] = tmp;
      IAEKF_DW.Q_a[i] = IAEKF_DW.P_k1_e[i];

      /* SystemInitialize for MATLAB Function: '<S3>/MATLAB Function' */
      IAEKF_DW.P_k1_eq[i] = tmp;
      IAEKF_DW.Q_g[i] = IAEKF_DW.P_k1_eq[i];
    }

    /* SystemInitialize for MATLAB Function: '<S3>/MATLAB Function' */
    /* ֵ��ͬЧ����ͬ����Ծ�ȷ�������ٶȴ���Ӱ�� */
    IAEKF_DW.R_f = 0.1;

    /* ֵ��ͬЧ����ͬ����Ծ�ȷ�������ٶȴ���Ӱ�� */
    /*  the mean of error  3*1ά */
    IAEKF_DW.q_n[0] = 0.1;
    IAEKF_DW.q_n[1] = 0.1;
    IAEKF_DW.q_n[2] = 0.1;

    /*  the mean of error  3*1ά */
    IAEKF_DW.r_p = 0.1;

    /*  the mean of error  3*1ά */
    IAEKF_DW.k_o = 1.0;
  }
}

/* Model terminate function */
void IAEKF_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
