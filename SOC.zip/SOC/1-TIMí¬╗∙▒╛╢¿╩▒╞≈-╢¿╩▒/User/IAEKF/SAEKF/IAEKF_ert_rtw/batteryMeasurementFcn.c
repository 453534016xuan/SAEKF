/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: batteryMeasurementFcn.c
 *
 * Code generated for Simulink model 'IAEKF'.
 *
 * Model version                  : 5.37
 * Simulink Coder version         : 9.6 (R2021b) 14-May-2021
 * C/C++ source code generated on : Fri Jun  2 18:55:59 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objective: MISRA C:2012 guidelines
 * Validation result: Not run
 */

#include "batteryMeasurementFcn.h"

/* Include model header file for global data */
#include "IAEKF.h"
#include "IAEKF_private.h"
#include "look1_binlxpw.h"

/* Output and update for Simulink Function: '<S7>/Simulink Function - Measurement Function2' */
real_T batteryMeasurementFcn(const real_T rtu_x[3])
{
  /* SignalConversion generated from: '<S20>/y' incorporates:
   *  Lookup_n-D: '<S20>/Em'
   *  Lookup_n-D: '<S20>/R0'
   *  Product: '<S20>/Product'
   *  SignalConversion generated from: '<S20>/Current'
   *  SignalConversion generated from: '<S20>/x'
   *  Sum: '<S20>/Add1'
   */
  return ((look1_binlxpw(rtu_x[0], rtCP_Em_bp01Data, rtCP_Em_tableData, 10U) -
           (look1_binlxpw(rtu_x[0], rtCP_R0_bp01Data, rtCP_R0_tableData, 10U) *
            IAEKF_B.Gain)) - rtu_x[1]) - rtu_x[2];
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
